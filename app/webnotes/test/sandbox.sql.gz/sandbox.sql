-- MySQL dump 10.13  Distrib 5.1.34, for apple-darwin9.5.0 (i386)
--
-- Host: localhost    Database: test3
-- ------------------------------------------------------
-- Server version	5.1.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__DocTypeCache`
--

DROP TABLE IF EXISTS `__DocTypeCache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__DocTypeCache` (
  `name` varchar(120) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `content` text,
  `server_code_compiled` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__DocTypeCache`
--

LOCK TABLES `__DocTypeCache` WRITE;
/*!40000 ALTER TABLE `__DocTypeCache` DISABLE KEYS */;
/*!40000 ALTER TABLE `__DocTypeCache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__SessionCache`
--

DROP TABLE IF EXISTS `__SessionCache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__SessionCache` (
  `user` varchar(120) DEFAULT NULL,
  `country` varchar(120) DEFAULT NULL,
  `cache` longtext
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__SessionCache`
--

LOCK TABLES `__SessionCache` WRITE;
/*!40000 ALTER TABLE `__SessionCache` DISABLE KEYS */;
INSERT INTO `__SessionCache` VALUES ('Administrator','Unknown Country','{\'profile\': {\'first_name\': \'Administrator\', \'last_name\': \'\', \'name\': \'Administrator\', \'roles\': [\'Administrator\', \'All\'], \'hide_tips\': 0, \'can_get_report\': [\'UserRole\', \'DefaultValue\', \'Profile\', \'File Group\', \'Property Setter\', \'Custom Field\', \'System Console\', \'Field Mapper Detail\', \'Table Mapper Detail\', \'DocType Mapper\', \'Print Format\', \'Page Role\', \'Page\', \'Custom Script\', \'DocPerm\', \'DocFormat\', \'DocField\', \'DocType\', \'DocType Label\', \'Default Home Page\', \'Control Panel\', \'Sandbox\', \'Role\', \'File\', \'Search Criteria\', \'Module Def Item\', \'Module Def Role\', \'Module Def\', \'Event User\', \'Event Role\'], \'can_read\': [\'Profile\', \'File Group\', \'Property Setter\', \'Custom Field\', \'System Console\', \'DocType Mapper\', \'Print Format\', \'Page\', \'Custom Script\', \'DocType\', \'DocType Label\', \'Control Panel\', \'Sandbox\', \'Role\', \'File\', \'Search Criteria\', \'Module Def\', \'Event\'], \'defaults\': {\'owner\': [\'Administrator\']}, \'can_write\': [\'Control Panel\', \'Custom Field\', \'Custom Script\', \'DocType\', \'DocType Label\', \'DocType Mapper\', \'Event\', \'File\', \'File Group\', \'Module Def\', \'Page\', \'Print Format\', \'Profile\', \'Property Setter\', \'Role\', \'Sandbox\', \'Search Criteria\', \'System Console\'], \'can_create\': [\'Custom Field\', \'Custom Script\', \'DocType\', \'DocType Label\', \'DocType Mapper\', \'File\', \'File Group\', \'Module Def\', \'Page\', \'Print Format\', \'Property Setter\', \'Role\', \'Sandbox\', \'Search Criteria\'], \'email\': \'admin@localhost\', \'recent\': \'\'}, \'n_online\': 2, \'home_page\': \'Login Page\', \'docs\': {\'_kl\': {\'Control Panel\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'owner\', \'name\'], \'Page\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'creation\', \'module\', \'owner\', \'style\', \'modified_by\', \'script\', \'show_in_menu\', \'content\', \'page_name\', \'_Page__content\', \'menu_index\', \'docstatus\', \'parent\', \'standard\', \'icon\', \'name\', \'idx\', \'static_content\', \'modified\', \'parenttype\', \'__script\', \'parent_node\', \'parentfield\'], \'DocType\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'__client_script\', \'section_style\', \'tag_fields\', \'is_transaction_doc\', \'creation\', \'search_fields\', \'module\', \'change_log\', \'print_outline\', \'owner\', \'in_dialog\', \'in_create\', \'read_only\', \'allow_email\', \'dt_template\', \'hide_heading\', \'issingle\', \'allow_rename\', \'smallicon\', \'_last_update\', \'allow_attach\', \'show_in_menu\', \'max_attachments\', \'version\', \'menu_index\', \'docstatus\', \'subject\', \'allow_copy\', \'istable\', \'description\', \'parent\', \'server_code\', \'allow_trash\', \'allow_print\', \'autoname\', \'client_script_core\', \'client_string\', \'use_template\', \'modified_by\', \'document_type\', \'name\', \'idx\', \'hide_toolbar\', \'colour\', \'client_script\', \'modified\', \'server_code_error\', \'name_case\', \'parenttype\', \'read_only_onload\', \'server_code_core\', \'parent_node\', \'parentfield\'], \'DocField\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'no_column\', \'no_copy\', \'oldfieldtype\', \'creation\', \'oldfieldname\', \'owner\', \'reqd\', \'in_filter\', \'print_hide\', \'modified_by\', \'label\', \'width\', \'trigger\', \'depends_on\', \'docstatus\', \'hidden\', \'permlevel\', \'description\', \'parent\', \'search_index\', \'allow_on_submit\', \'icon\', \'name\', \'idx\', \'default\', \'colour\', \'modified\', \'parenttype\', \'fieldname\', \'fieldtype\', \'options\', \'report_hide\', \'parentfield\'], \'DocPerm\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'cancel\', \'amend\', \'execute\', \'modified_by\', \'name\', \'parent\', \'read\', \'create\', \'creation\', \'modified\', \'submit\', \'write\', \'idx\', \'parenttype\', \'role\', \'owner\', \'docstatus\', \'permlevel\', \'match\', \'parentfield\']}, \'_vl\': [[\'Control Panel\', None, None, None, \'\', \'Control Panel\'], [\'DocType\', None, None, None, \'\', \'Tabbed\', None, None, \'2011-07-22 19:08:58\', None, \'Core\', None, None, \'Administrator\', None, 1, 1, None, None, None, None, None, None, \'1311340897\', None, 0, None, 2, None, 0, None, None, None, None, None, None, None, None, \'EV.#####\', None, \'---intro_html---\\n\\n<div style=\"padding: 8px; background-color: #EEF; border: 1px solid #CCF; margin-bottom: 8px;\">\\n  %(ref)s\\n  <a href=\"javascript:loadpage(\\\'_calendar\\\')\">Go To Calendar</a>\\n</div>\\n\\n---ref_html---\\n\\nReference : <a href=\"javascript:loaddoc(\\\'%(dt)s\\\', \\\'%(dn)s\\\')\">%(dn)s</a><br><br>\', None, \'Administrator\', None, \'Event\', None, None, \'White:FFF\', None, \'2011-07-22 19:08:58\', \' \', None, None, None, None, None, None], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00013\', \'Event\', 1, 1, \'2011-07-22 19:08:58\', \'2011-07-22 19:08:58\', None, 1, 1, \'DocType\', \'All\', \'Administrator\', 0, 0, \'owner\', \'permissions\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Details\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00134\', 1, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'HTML\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Intro HTML\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00135\', 2, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'HTML\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Date\', \'2011-07-22 19:08:58\', \'event_date\', \'Administrator\', None, None, None, \'Administrator\', \'Event Date\', None, None, None, 0, None, 0, None, \'Event\', 1, None, None, \'FL00136\', 3, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_date\', \'Date\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Time\', \'2011-07-22 19:08:58\', \'event_hour\', \'Administrator\', None, None, None, \'Administrator\', \'Event Time\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00137\', 4, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_hour\', \'Time\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:08:58\', \'event_name\', \'Administrator\', None, None, None, \'Administrator\', \'Event Name\', None, None, None, 0, 1, 0, None, \'Event\', None, None, None, \'FL00138\', 5, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_name\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:08:58\', \'description\', \'Administrator\', None, None, None, \'Administrator\', \'Description\', \'300px\', None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00139\', 6, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'description\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:08:58\', \'notes\', \'Administrator\', None, None, None, \'Administrator\', \'Notes\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00140\', 7, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'notes\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Select\', \'2011-07-22 19:08:58\', \'event_type\', \'Administrator\', None, None, None, \'Administrator\', \'Event Type\', None, None, None, 0, None, 0, None, \'Event\', 1, None, None, \'FL00141\', 8, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_type\', \'Select\', \'Private\\nPublic\\nCancel\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Participants\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00142\', 9, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Column Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Individuals\', \'50%\', None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00143\', 10, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Column Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Table\', \'2011-07-22 19:08:58\', \'event_individuals\', \'Administrator\', None, None, None, \'Administrator\', \'Event Individuals\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00144\', 11, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_individuals\', \'Table\', \'Event User\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Column Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Groups\', \'50%\', None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00145\', 12, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Column Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Table\', \'2011-07-22 19:08:58\', \'event_roles\', \'Administrator\', None, None, None, \'Administrator\', \'Event Roles\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00146\', 13, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_roles\', \'Table\', \'Event Role\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:08:58\', \'ref_type\', \'Administrator\', None, None, None, \'Administrator\', \'Ref Type\', None, None, None, 0, 0, 0, None, \'Event\', None, None, None, \'FL00147\', 14, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'ref_type\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:08:58\', \'ref_name\', \'Administrator\', None, None, None, \'Administrator\', \'Ref Name\', None, None, None, 0, 0, 0, None, \'Event\', None, None, None, \'FL00148\', 15, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'ref_name\', \'Data\', None, None, \'fields\'], [\'DocType\', None, None, None, None, \'Simple\', None, None, \'2011-07-22 19:08:58\', None, \'Core\', None, None, \'Administrator\', None, None, None, None, None, None, None, None, None, None, None, 0, None, None, None, 0, None, None, 1, None, None, None, None, None, \'EVP.#####\', None, None, None, \'Administrator\', None, \'Event User\', None, None, \'White:FFF\', None, \'2011-07-22 19:08:58\', \' \', None, None, None, None, None, None], [\'DocField\', None, None, None, None, None, \'Select\', \'2011-07-22 19:08:58\', \'person\', \'Administrator\', None, None, None, \'Administrator\', \'Person\', None, None, None, 0, None, 0, None, \'Event User\', 1, None, None, \'FL00150\', 1, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'person\', \'Select\', \'\\nAdministrator\\nGuest\', None, \'fields\'], [\'DocType\', None, None, None, None, \'Simple\', None, None, \'2011-07-22 19:08:58\', None, \'Core\', None, None, \'Administrator\', None, None, None, None, None, None, None, None, None, None, None, 0, None, None, None, 0, None, None, 1, None, None, None, None, None, \'__EVR.#####\', None, None, None, \'Administrator\', None, \'Event Role\', None, None, \'White:FFF\', None, \'2011-07-22 19:08:58\', None, None, None, None, None, None, None], [\'DocField\', None, None, None, None, None, \'Link\', \'2011-07-22 19:08:58\', \'role\', \'Administrator\', None, None, None, \'Administrator\', \'Role\', None, None, None, 0, None, 0, None, \'Event Role\', None, None, None, \'FL00149\', 1, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'role\', \'Link\', \'Role\', None, \'fields\'], [\'DocType\', None, None, None, \'\', \'Tabbed\', None, None, \'2011-07-22 19:09:01\', \'criteria_name\', \'Core\', None, None, \'Administrator\', None, None, None, None, None, None, None, None, None, \'1311340897\', None, 0, None, 4, None, 0, None, None, None, None, None, None, None, None, None, None, None, None, \'Administrator\', None, \'Search Criteria\', None, None, \'White:FFF\', None, \'2011-07-22 19:09:01\', \' \', None, None, None, None, None, None], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00029\', \'Search Criteria\', 1, 1, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, 1, 1, \'DocType\', \'All\', \'Administrator\', 0, 0, None, \'permissions\'], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00030\', \'Search Criteria\', 1, None, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, None, 2, \'DocType\', \'All\', \'Administrator\', 0, 1, None, \'permissions\'], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00031\', \'Search Criteria\', 1, None, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, 1, 3, \'DocType\', \'Administrator\', \'Administrator\', 0, 0, None, \'permissions\'], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00032\', \'Search Criteria\', 1, None, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, None, 4, \'DocType\', \'Administrator\', \'Administrator\', 0, 1, None, \'permissions\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Details\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00310\', 1, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Check\', \'2011-07-22 19:09:01\', \'disabled\', \'Administrator\', None, None, None, \'Administrator\', \'Disabled\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00311\', 2, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'disabled\', \'Check\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Link\', \'2011-07-22 19:09:01\', \'module\', \'Administrator\', 0, None, None, \'Administrator\', \'Module\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00312\', 3, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'module\', \'Link\', \'Module Def\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Select\', \'2011-07-22 19:09:01\', \'standard\', \'Administrator\', 0, None, None, \'Administrator\', \'Standard\', None, None, None, 0, None, 0, None, \'Search Criteria\', 1, None, None, \'FL00313\', 4, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'standard\', \'Select\', \'\\nYes\\nNo\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'criteria_name\', \'Administrator\', None, None, None, \'Administrator\', \'Criteria Name\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00314\', 5, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'criteria_name\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'description\', \'Administrator\', None, None, None, \'Administrator\', \'Description\', \'300px\', None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00315\', 6, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'description\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Query Details\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00316\', 7, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'doc_type\', \'Administrator\', None, None, None, \'Administrator\', \'Doc Type\', None, None, None, 0, 1, 1, None, \'Search Criteria\', None, None, None, \'FL00317\', 8, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'doc_type\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'filters\', \'Administrator\', None, None, None, \'Administrator\', \'Filters\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00318\', 9, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'filters\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'columns\', \'Administrator\', None, None, None, \'Administrator\', \'Columns\', None, None, None, 0, 1, 1, None, \'Search Criteria\', None, None, None, \'FL00319\', 10, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'columns\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'parent_doc_type\', \'Administrator\', None, None, None, \'Administrator\', \'Parent Doc Type\', None, None, None, 0, 1, 1, None, \'Search Criteria\', None, None, None, \'FL00320\', 11, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'parent_doc_type\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'add_cond\', \'Administrator\', None, None, None, \'Administrator\', \'Additional Conditions\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00321\', 12, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'add_cond\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'add_col\', \'Administrator\', None, None, None, \'Administrator\', \'Additional Columns\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00322\', 13, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'add_col\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'add_tab\', \'Administrator\', None, None, None, \'Administrator\', \'Additional Tables\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00323\', 14, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'add_tab\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'dis_filters\', \'Administrator\', None, None, None, \'Administrator\', \'Disabled Filters\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00324\', 15, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'dis_filters\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'group_by\', \'Administrator\', None, None, None, \'Administrator\', \'Group By\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00325\', 16, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'group_by\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'graph_series\', \'Administrator\', None, None, None, \'Administrator\', \'Graph Series\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00326\', 17, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'graph_series\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'graph_values\', \'Administrator\', None, None, None, \'Administrator\', \'Graph Values\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00327\', 18, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'graph_values\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'sort_by\', \'Administrator\', None, None, None, \'Administrator\', \'Sort By\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00328\', 19, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'sort_by\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'sort_order\', \'Administrator\', None, None, None, \'Administrator\', \'Sort Order\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00329\', 20, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'sort_order\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Int\', \'2011-07-22 19:09:01\', \'page_len\', \'Administrator\', None, None, None, \'Administrator\', \'Page Len\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00330\', 21, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'page_len\', \'Int\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Client Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00331\', 22, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Code\', \'2011-07-22 19:09:01\', \'report_script\', \'Administrator\', None, None, None, \'Administrator\', \'Report Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00332\', 23, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'report_script\', \'Code\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Server Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00333\', 24, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Code\', \'2011-07-22 19:09:01\', \'server_script\', \'Administrator\', None, None, None, \'Administrator\', \'Report Server Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00334\', 25, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'server_script\', \'Code\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Overload Query\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00335\', 26, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Code\', \'2011-07-22 19:09:01\', \'custom_query\', \'Administrator\', None, None, None, \'Administrator\', \'Custom Query\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00336\', 27, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'custom_query\', \'Code\', None, None, \'fields\'], [\'Page\', None, None, None, \'2011-07-22 19:09:02\', \'Core\', \'Administrator\', None, \'Administrator\', None, None, \'<div style=\"margin: 100px auto; width:320px; border: 1px solid #888; padding: 8px; background-color:#FFF\" id=\\\'login_wrapper\\\'>\\n<h1 style=\"margin-left: 8px; margin-bottom: 24px;\">Login</h1>\\n<table border=\"0\" cellspacing=\"8\">\\n<tbody>\\n<tr>\\n<td>Login Id</td>\\n<td><input id=\"login_id\" type=\"text\" style=\"width: 180px\"/></td>\\n</tr>\\n<tr>\\n<td>Password</td>\\n<td><input id=\"password\" type=\"password\" style=\"width: 180px\" /></td>\\n</tr>\\n<tr>\\n<td style=\"text-align:right\"><input id=\"remember_me\" type=\"checkbox\" /></td>\\n<td>Remember Me</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_message\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_btn\"></td>\\n</tr>\\n</tbody>\\n</table>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"pscript.show_forgot_password()\">Forgot Password</span></p>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"err_console.show()\">Debug</span></p>\\n</div>\', \'Login Page\', \'<div style=\"margin: 100px auto; width:320px; border: 1px solid #888; padding: 8px; background-color:#FFF\" id=\\\'login_wrapper\\\'>\\n<h1 style=\"margin-left: 8px; margin-bottom: 24px;\">Login</h1>\\n<table border=\"0\" cellspacing=\"8\">\\n<tbody>\\n<tr>\\n<td>Login Id</td>\\n<td><input id=\"login_id\" type=\"text\" style=\"width: 180px\"/></td>\\n</tr>\\n<tr>\\n<td>Password</td>\\n<td><input id=\"password\" type=\"password\" style=\"width: 180px\" /></td>\\n</tr>\\n<tr>\\n<td style=\"text-align:right\"><input id=\"remember_me\" type=\"checkbox\" /></td>\\n<td>Remember Me</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_message\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_btn\"></td>\\n</tr>\\n</tbody>\\n</table>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"pscript.show_forgot_password()\">Forgot Password</span></p>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"err_console.show()\">Debug</span></p>\\n</div>\', None, 0, None, \'Yes\', None, \'Login Page\', None, None, \'2011-07-22 19:09:02\', None, \'pscript[\\\'onload_Login Page\\\'] = function(){\\n\\tvar lw = $i(\\\'login_wrapper\\\')\\n\\t$bs(lw, \\\'1px 1px 3px #888\\\');\\n\\t$bg(document.getElementsByTagName(\\\'body\\\')[0], \\\'#DDD\\\');\\n\\t\\n\\tpscript.login_btn = $btn(\\\'login_btn\\\', \\\'Login\\\', pscript.doLogin)\\n\\t\\n    keypress_observers.push(new function() {\\n      this.notify_keypress = function(kc) { if(kc==13 && $i(\"password\").value) pscript.doLogin(); }\\n    }\\n  );\\n}\\n\\n\\n// Login Callback\\npscript.onLoginReply = function(r, rtext) {\\n\\tpscript.login_btn.done_working();\\n    if(r.message==\"Logged In\"){\\n        window.location.href=\\\'index.cgi\\\' + (get_url_arg(\\\'page\\\') ? (\\\'?page=\\\'+get_url_arg(\\\'page\\\')) : \\\'\\\');\\n    } else {\\n        $i(\\\'login_message\\\').innerHTML = \\\'<span style=\"color: RED;\">\\\'+eval(r.message)+\\\'</span>\\\';\\n        //if(r.exc)alert(r.exc);\\n    }\\n}\\n\\n\\n// Login\\npscript.doLogin = function(){\\n\\n    var args = {};\\n    args[\\\'usr\\\']=$i(\"login_id\").value;\\n    args[\\\'pwd\\\']=$i(\"password\").value;\\n    if($i(\\\'remember_me\\\').checked) \\n      args[\\\'remember_me\\\'] = 1;\\n\\n\\tpscript.login_btn.set_working();\\n\\t\\n    $c(\"login\", args, pscript.onLoginReply);\\n}\\n\\n\\npscript.show_forgot_password = function(){\\n    // create dialog\\n    var d = new Dialog(400, 400, \\\'Reset Password\\\')\\n    d.make_body([[\\\'HTML\\\',\\\'Title\\\',\\\'Enter your email id to reset the password\\\'], [\\\'Data\\\',\\\'Email Id\\\'], [\\\'Button\\\',\\\'Reset\\\']]);\\n\\n    var callback = function(r,rt) { \\n        if(!r.exc) pscript.forgot_dialog.hide();\\n    }\\n\\n    d.widgets[\\\'Reset\\\'].onclick = function() {\\n      $c(\\\'reset_password\\\', {user: pscript.forgot_dialog.widgets[\\\'Email Id\\\'].value}, callback)\\n    }\\n    d.show();\\n    pscript.forgot_dialog = d;\\n}\', None, None]]}, \'start_items\': [[\'System Console\', \'System Console\', \'\', \'\', 0], [\'Control Panel\', \'Control Panel\', \'\', \'controller.png\', 5]], \'sysdefaults\': {}, \'letter_heads\': {}, \'dt_labels\': {}, \'account_name\': \'\'}'),('Guest','Unknown Country','{\'profile\': {\'first_name\': \'Guest\', \'last_name\': \'\', \'name\': \'Guest\', \'roles\': [\'Guest\', \'Guest\'], \'hide_tips\': 0, \'can_get_report\': [], \'can_read\': [], \'defaults\': {\'owner\': [\'Guest\'], \'hide_sidebars\': [\'1\'], \'hide_webnotes_toolbar\': [\'1\']}, \'can_write\': [], \'can_create\': [], \'email\': \'guest@localhost\', \'recent\': \'\'}, \'n_online\': 2, \'home_page\': \'Login Page\', \'docs\': {\'_kl\': {\'Control Panel\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'owner\', \'name\'], \'Page\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'creation\', \'module\', \'owner\', \'style\', \'modified_by\', \'script\', \'show_in_menu\', \'content\', \'page_name\', \'_Page__content\', \'menu_index\', \'docstatus\', \'parent\', \'standard\', \'icon\', \'name\', \'idx\', \'static_content\', \'modified\', \'parenttype\', \'__script\', \'parent_node\', \'parentfield\'], \'DocType\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'__client_script\', \'section_style\', \'tag_fields\', \'is_transaction_doc\', \'creation\', \'search_fields\', \'module\', \'change_log\', \'print_outline\', \'owner\', \'in_dialog\', \'in_create\', \'read_only\', \'allow_email\', \'dt_template\', \'hide_heading\', \'issingle\', \'allow_rename\', \'smallicon\', \'_last_update\', \'allow_attach\', \'show_in_menu\', \'max_attachments\', \'version\', \'menu_index\', \'docstatus\', \'subject\', \'allow_copy\', \'istable\', \'description\', \'parent\', \'server_code\', \'allow_trash\', \'allow_print\', \'autoname\', \'client_script_core\', \'client_string\', \'use_template\', \'modified_by\', \'document_type\', \'name\', \'idx\', \'hide_toolbar\', \'colour\', \'client_script\', \'modified\', \'server_code_error\', \'name_case\', \'parenttype\', \'read_only_onload\', \'server_code_core\', \'parent_node\', \'parentfield\'], \'DocField\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'no_column\', \'no_copy\', \'oldfieldtype\', \'creation\', \'oldfieldname\', \'owner\', \'reqd\', \'in_filter\', \'print_hide\', \'modified_by\', \'label\', \'width\', \'trigger\', \'depends_on\', \'docstatus\', \'hidden\', \'permlevel\', \'description\', \'parent\', \'search_index\', \'allow_on_submit\', \'icon\', \'name\', \'idx\', \'default\', \'colour\', \'modified\', \'parenttype\', \'fieldname\', \'fieldtype\', \'options\', \'report_hide\', \'parentfield\'], \'DocPerm\': [\'doctype\', \'localname\', \'__oldparent\', \'__unsaved\', \'cancel\', \'amend\', \'execute\', \'modified_by\', \'name\', \'parent\', \'read\', \'create\', \'creation\', \'modified\', \'submit\', \'write\', \'idx\', \'parenttype\', \'role\', \'owner\', \'docstatus\', \'permlevel\', \'match\', \'parentfield\']}, \'_vl\': [[\'Control Panel\', None, None, None, \'\', \'Control Panel\'], [\'DocType\', None, None, None, \'\', \'Tabbed\', None, None, \'2011-07-22 19:08:58\', None, \'Core\', None, None, \'Administrator\', None, 1, 1, None, None, None, None, None, None, \'1311340897\', None, 0, None, 2, None, 0, None, None, None, None, None, None, None, None, \'EV.#####\', None, \'---intro_html---\\n\\n<div style=\"padding: 8px; background-color: #EEF; border: 1px solid #CCF; margin-bottom: 8px;\">\\n  %(ref)s\\n  <a href=\"javascript:loadpage(\\\'_calendar\\\')\">Go To Calendar</a>\\n</div>\\n\\n---ref_html---\\n\\nReference : <a href=\"javascript:loaddoc(\\\'%(dt)s\\\', \\\'%(dn)s\\\')\">%(dn)s</a><br><br>\', None, \'Administrator\', None, \'Event\', None, None, \'White:FFF\', None, \'2011-07-22 19:08:58\', \' \', None, None, None, None, None, None], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00013\', \'Event\', 1, 1, \'2011-07-22 19:08:58\', \'2011-07-22 19:08:58\', None, 1, 1, \'DocType\', \'All\', \'Administrator\', 0, 0, \'owner\', \'permissions\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Details\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00134\', 1, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'HTML\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Intro HTML\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00135\', 2, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'HTML\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Date\', \'2011-07-22 19:08:58\', \'event_date\', \'Administrator\', None, None, None, \'Administrator\', \'Event Date\', None, None, None, 0, None, 0, None, \'Event\', 1, None, None, \'FL00136\', 3, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_date\', \'Date\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Time\', \'2011-07-22 19:08:58\', \'event_hour\', \'Administrator\', None, None, None, \'Administrator\', \'Event Time\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00137\', 4, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_hour\', \'Time\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:08:58\', \'event_name\', \'Administrator\', None, None, None, \'Administrator\', \'Event Name\', None, None, None, 0, 1, 0, None, \'Event\', None, None, None, \'FL00138\', 5, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_name\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:08:58\', \'description\', \'Administrator\', None, None, None, \'Administrator\', \'Description\', \'300px\', None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00139\', 6, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'description\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:08:58\', \'notes\', \'Administrator\', None, None, None, \'Administrator\', \'Notes\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00140\', 7, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'notes\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Select\', \'2011-07-22 19:08:58\', \'event_type\', \'Administrator\', None, None, None, \'Administrator\', \'Event Type\', None, None, None, 0, None, 0, None, \'Event\', 1, None, None, \'FL00141\', 8, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_type\', \'Select\', \'Private\\nPublic\\nCancel\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Participants\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00142\', 9, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Column Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Individuals\', \'50%\', None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00143\', 10, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Column Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Table\', \'2011-07-22 19:08:58\', \'event_individuals\', \'Administrator\', None, None, None, \'Administrator\', \'Event Individuals\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00144\', 11, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_individuals\', \'Table\', \'Event User\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Column Break\', \'2011-07-22 19:08:58\', None, \'Administrator\', None, None, None, \'Administrator\', \'Groups\', \'50%\', None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00145\', 12, None, None, \'2011-07-22 19:08:58\', \'DocType\', None, \'Column Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Table\', \'2011-07-22 19:08:58\', \'event_roles\', \'Administrator\', None, None, None, \'Administrator\', \'Event Roles\', None, None, None, 0, None, 0, None, \'Event\', None, None, None, \'FL00146\', 13, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'event_roles\', \'Table\', \'Event Role\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:08:58\', \'ref_type\', \'Administrator\', None, None, None, \'Administrator\', \'Ref Type\', None, None, None, 0, 0, 0, None, \'Event\', None, None, None, \'FL00147\', 14, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'ref_type\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:08:58\', \'ref_name\', \'Administrator\', None, None, None, \'Administrator\', \'Ref Name\', None, None, None, 0, 0, 0, None, \'Event\', None, None, None, \'FL00148\', 15, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'ref_name\', \'Data\', None, None, \'fields\'], [\'DocType\', None, None, None, None, \'Simple\', None, None, \'2011-07-22 19:08:58\', None, \'Core\', None, None, \'Administrator\', None, None, None, None, None, None, None, None, None, None, None, 0, None, None, None, 0, None, None, 1, None, None, None, None, None, \'EVP.#####\', None, None, None, \'Administrator\', None, \'Event User\', None, None, \'White:FFF\', None, \'2011-07-22 19:08:58\', \' \', None, None, None, None, None, None], [\'DocField\', None, None, None, None, None, \'Select\', \'2011-07-22 19:08:58\', \'person\', \'Administrator\', None, None, None, \'Administrator\', \'Person\', None, None, None, 0, None, 0, None, \'Event User\', 1, None, None, \'FL00150\', 1, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'person\', \'Select\', \'\\nAdministrator\\nGuest\', None, \'fields\'], [\'DocType\', None, None, None, None, \'Simple\', None, None, \'2011-07-22 19:08:58\', None, \'Core\', None, None, \'Administrator\', None, None, None, None, None, None, None, None, None, None, None, 0, None, None, None, 0, None, None, 1, None, None, None, None, None, \'__EVR.#####\', None, None, None, \'Administrator\', None, \'Event Role\', None, None, \'White:FFF\', None, \'2011-07-22 19:08:58\', None, None, None, None, None, None, None], [\'DocField\', None, None, None, None, None, \'Link\', \'2011-07-22 19:08:58\', \'role\', \'Administrator\', None, None, None, \'Administrator\', \'Role\', None, None, None, 0, None, 0, None, \'Event Role\', None, None, None, \'FL00149\', 1, None, None, \'2011-07-22 19:08:58\', \'DocType\', \'role\', \'Link\', \'Role\', None, \'fields\'], [\'DocType\', None, None, None, \'\', \'Tabbed\', None, None, \'2011-07-22 19:09:01\', \'criteria_name\', \'Core\', None, None, \'Administrator\', None, None, None, None, None, None, None, None, None, \'1311340897\', None, 0, None, 4, None, 0, None, None, None, None, None, None, None, None, None, None, None, None, \'Administrator\', None, \'Search Criteria\', None, None, \'White:FFF\', None, \'2011-07-22 19:09:01\', \' \', None, None, None, None, None, None], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00029\', \'Search Criteria\', 1, 1, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, 1, 1, \'DocType\', \'All\', \'Administrator\', 0, 0, None, \'permissions\'], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00030\', \'Search Criteria\', 1, None, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, None, 2, \'DocType\', \'All\', \'Administrator\', 0, 1, None, \'permissions\'], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00031\', \'Search Criteria\', 1, None, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, 1, 3, \'DocType\', \'Administrator\', \'Administrator\', 0, 0, None, \'permissions\'], [\'DocPerm\', None, None, None, None, None, None, \'Administrator\', \'PERM00032\', \'Search Criteria\', 1, None, \'2011-07-22 19:09:01\', \'2011-07-22 19:09:01\', None, None, 4, \'DocType\', \'Administrator\', \'Administrator\', 0, 1, None, \'permissions\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Details\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00310\', 1, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Check\', \'2011-07-22 19:09:01\', \'disabled\', \'Administrator\', None, None, None, \'Administrator\', \'Disabled\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00311\', 2, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'disabled\', \'Check\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Link\', \'2011-07-22 19:09:01\', \'module\', \'Administrator\', 0, None, None, \'Administrator\', \'Module\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00312\', 3, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'module\', \'Link\', \'Module Def\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Select\', \'2011-07-22 19:09:01\', \'standard\', \'Administrator\', 0, None, None, \'Administrator\', \'Standard\', None, None, None, 0, None, 0, None, \'Search Criteria\', 1, None, None, \'FL00313\', 4, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'standard\', \'Select\', \'\\nYes\\nNo\', None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'criteria_name\', \'Administrator\', None, None, None, \'Administrator\', \'Criteria Name\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00314\', 5, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'criteria_name\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'description\', \'Administrator\', None, None, None, \'Administrator\', \'Description\', \'300px\', None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00315\', 6, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'description\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Query Details\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00316\', 7, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'doc_type\', \'Administrator\', None, None, None, \'Administrator\', \'Doc Type\', None, None, None, 0, 1, 1, None, \'Search Criteria\', None, None, None, \'FL00317\', 8, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'doc_type\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'filters\', \'Administrator\', None, None, None, \'Administrator\', \'Filters\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00318\', 9, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'filters\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'columns\', \'Administrator\', None, None, None, \'Administrator\', \'Columns\', None, None, None, 0, 1, 1, None, \'Search Criteria\', None, None, None, \'FL00319\', 10, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'columns\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'parent_doc_type\', \'Administrator\', None, None, None, \'Administrator\', \'Parent Doc Type\', None, None, None, 0, 1, 1, None, \'Search Criteria\', None, None, None, \'FL00320\', 11, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'parent_doc_type\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'add_cond\', \'Administrator\', None, None, None, \'Administrator\', \'Additional Conditions\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00321\', 12, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'add_cond\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'add_col\', \'Administrator\', None, None, None, \'Administrator\', \'Additional Columns\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00322\', 13, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'add_col\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'add_tab\', \'Administrator\', None, None, None, \'Administrator\', \'Additional Tables\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00323\', 14, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'add_tab\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Text\', \'2011-07-22 19:09:01\', \'dis_filters\', \'Administrator\', None, None, None, \'Administrator\', \'Disabled Filters\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00324\', 15, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'dis_filters\', \'Text\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'group_by\', \'Administrator\', None, None, None, \'Administrator\', \'Group By\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00325\', 16, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'group_by\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'graph_series\', \'Administrator\', None, None, None, \'Administrator\', \'Graph Series\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00326\', 17, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'graph_series\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'graph_values\', \'Administrator\', None, None, None, \'Administrator\', \'Graph Values\', None, None, None, 0, 0, 0, None, \'Search Criteria\', None, None, None, \'FL00327\', 18, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'graph_values\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'sort_by\', \'Administrator\', None, None, None, \'Administrator\', \'Sort By\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00328\', 19, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'sort_by\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Data\', \'2011-07-22 19:09:01\', \'sort_order\', \'Administrator\', None, None, None, \'Administrator\', \'Sort Order\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00329\', 20, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'sort_order\', \'Data\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Int\', \'2011-07-22 19:09:01\', \'page_len\', \'Administrator\', None, None, None, \'Administrator\', \'Page Len\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00330\', 21, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'page_len\', \'Int\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Client Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00331\', 22, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Code\', \'2011-07-22 19:09:01\', \'report_script\', \'Administrator\', None, None, None, \'Administrator\', \'Report Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00332\', 23, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'report_script\', \'Code\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Server Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00333\', 24, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Code\', \'2011-07-22 19:09:01\', \'server_script\', \'Administrator\', None, None, None, \'Administrator\', \'Report Server Script\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00334\', 25, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'server_script\', \'Code\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Section Break\', \'2011-07-22 19:09:01\', None, \'Administrator\', None, None, None, \'Administrator\', \'Overload Query\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00335\', 26, None, None, \'2011-07-22 19:09:01\', \'DocType\', None, \'Section Break\', None, None, \'fields\'], [\'DocField\', None, None, None, None, None, \'Code\', \'2011-07-22 19:09:01\', \'custom_query\', \'Administrator\', None, None, None, \'Administrator\', \'Custom Query\', None, None, None, 0, None, 0, None, \'Search Criteria\', None, None, None, \'FL00336\', 27, None, None, \'2011-07-22 19:09:01\', \'DocType\', \'custom_query\', \'Code\', None, None, \'fields\'], [\'Page\', None, None, None, \'2011-07-22 19:09:02\', \'Core\', \'Administrator\', None, \'Administrator\', None, None, \'<div style=\"margin: 100px auto; width:320px; border: 1px solid #888; padding: 8px; background-color:#FFF\" id=\\\'login_wrapper\\\'>\\n<h1 style=\"margin-left: 8px; margin-bottom: 24px;\">Login</h1>\\n<table border=\"0\" cellspacing=\"8\">\\n<tbody>\\n<tr>\\n<td>Login Id</td>\\n<td><input id=\"login_id\" type=\"text\" style=\"width: 180px\"/></td>\\n</tr>\\n<tr>\\n<td>Password</td>\\n<td><input id=\"password\" type=\"password\" style=\"width: 180px\" /></td>\\n</tr>\\n<tr>\\n<td style=\"text-align:right\"><input id=\"remember_me\" type=\"checkbox\" /></td>\\n<td>Remember Me</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_message\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_btn\"></td>\\n</tr>\\n</tbody>\\n</table>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"pscript.show_forgot_password()\">Forgot Password</span></p>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"err_console.show()\">Debug</span></p>\\n</div>\', \'Login Page\', \'<div style=\"margin: 100px auto; width:320px; border: 1px solid #888; padding: 8px; background-color:#FFF\" id=\\\'login_wrapper\\\'>\\n<h1 style=\"margin-left: 8px; margin-bottom: 24px;\">Login</h1>\\n<table border=\"0\" cellspacing=\"8\">\\n<tbody>\\n<tr>\\n<td>Login Id</td>\\n<td><input id=\"login_id\" type=\"text\" style=\"width: 180px\"/></td>\\n</tr>\\n<tr>\\n<td>Password</td>\\n<td><input id=\"password\" type=\"password\" style=\"width: 180px\" /></td>\\n</tr>\\n<tr>\\n<td style=\"text-align:right\"><input id=\"remember_me\" type=\"checkbox\" /></td>\\n<td>Remember Me</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_message\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td>&nbsp;</td>\\n<td id=\"login_btn\"></td>\\n</tr>\\n</tbody>\\n</table>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"pscript.show_forgot_password()\">Forgot Password</span></p>\\n<p style=\"margin-left: 8px;\"><span class=\"link_type\" onclick=\"err_console.show()\">Debug</span></p>\\n</div>\', None, 0, None, \'Yes\', None, \'Login Page\', None, None, \'2011-07-22 19:09:02\', None, \'pscript[\\\'onload_Login Page\\\'] = function(){\\n\\tvar lw = $i(\\\'login_wrapper\\\')\\n\\t$bs(lw, \\\'1px 1px 3px #888\\\');\\n\\t$bg(document.getElementsByTagName(\\\'body\\\')[0], \\\'#DDD\\\');\\n\\t\\n\\tpscript.login_btn = $btn(\\\'login_btn\\\', \\\'Login\\\', pscript.doLogin)\\n\\t\\n    keypress_observers.push(new function() {\\n      this.notify_keypress = function(kc) { if(kc==13 && $i(\"password\").value) pscript.doLogin(); }\\n    }\\n  );\\n}\\n\\n\\n// Login Callback\\npscript.onLoginReply = function(r, rtext) {\\n\\tpscript.login_btn.done_working();\\n    if(r.message==\"Logged In\"){\\n        window.location.href=\\\'index.cgi\\\' + (get_url_arg(\\\'page\\\') ? (\\\'?page=\\\'+get_url_arg(\\\'page\\\')) : \\\'\\\');\\n    } else {\\n        $i(\\\'login_message\\\').innerHTML = \\\'<span style=\"color: RED;\">\\\'+eval(r.message)+\\\'</span>\\\';\\n        //if(r.exc)alert(r.exc);\\n    }\\n}\\n\\n\\n// Login\\npscript.doLogin = function(){\\n\\n    var args = {};\\n    args[\\\'usr\\\']=$i(\"login_id\").value;\\n    args[\\\'pwd\\\']=$i(\"password\").value;\\n    if($i(\\\'remember_me\\\').checked) \\n      args[\\\'remember_me\\\'] = 1;\\n\\n\\tpscript.login_btn.set_working();\\n\\t\\n    $c(\"login\", args, pscript.onLoginReply);\\n}\\n\\n\\npscript.show_forgot_password = function(){\\n    // create dialog\\n    var d = new Dialog(400, 400, \\\'Reset Password\\\')\\n    d.make_body([[\\\'HTML\\\',\\\'Title\\\',\\\'Enter your email id to reset the password\\\'], [\\\'Data\\\',\\\'Email Id\\\'], [\\\'Button\\\',\\\'Reset\\\']]);\\n\\n    var callback = function(r,rt) { \\n        if(!r.exc) pscript.forgot_dialog.hide();\\n    }\\n\\n    d.widgets[\\\'Reset\\\'].onclick = function() {\\n      $c(\\\'reset_password\\\', {user: pscript.forgot_dialog.widgets[\\\'Email Id\\\'].value}, callback)\\n    }\\n    d.show();\\n    pscript.forgot_dialog = d;\\n}\', None, None]]}, \'start_items\': [], \'sysdefaults\': {}, \'letter_heads\': {}, \'dt_labels\': {}, \'account_name\': \'\'}');
/*!40000 ALTER TABLE `__SessionCache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__file_timestamp`
--

DROP TABLE IF EXISTS `__file_timestamp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__file_timestamp` (
  `file_name` varchar(180) NOT NULL,
  `tstamp` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__file_timestamp`
--

LOCK TABLES `__file_timestamp` WRITE;
/*!40000 ALTER TABLE `__file_timestamp` DISABLE KEYS */;
INSERT INTO `__file_timestamp` VALUES ('cgi-bin/core/doctype/comment_widget_record/comment_widget_record.txt','1311340897'),('cgi-bin/core/doctype/control_panel/control_panel.txt','1311340897'),('cgi-bin/core/doctype/custom_field/custom_field.txt','1311340897'),('cgi-bin/core/doctype/custom_script/custom_script.txt','1311340897'),('cgi-bin/core/doctype/defaultvalue/defaultvalue.txt','1311340897'),('cgi-bin/core/doctype/default_home_page/default_home_page.txt','1311340897'),('cgi-bin/core/doctype/docfield/docfield.txt','1311340897'),('cgi-bin/core/doctype/docformat/docformat.txt','1311340897'),('cgi-bin/core/doctype/docperm/docperm.txt','1311340897'),('cgi-bin/core/doctype/doctrigger/doctrigger.txt','1311340897'),('cgi-bin/core/doctype/doctype/doctype.txt','1311341869'),('cgi-bin/core/doctype/doctype_label/doctype_label.txt','1311340897'),('cgi-bin/core/doctype/doctype_mapper/doctype_mapper.txt','1311340897'),('cgi-bin/core/doctype/event/event.txt','1311340897'),('cgi-bin/core/doctype/event_role/event_role.txt','1311340897'),('cgi-bin/core/doctype/event_user/event_user.txt','1311340897'),('cgi-bin/core/doctype/field_mapper_detail/field_mapper_detail.txt','1311340897'),('cgi-bin/core/doctype/file/file.txt','1311340897'),('cgi-bin/core/doctype/file_data/file_data.txt','1311340897'),('cgi-bin/core/doctype/file_group/file_group.txt','1311340897'),('cgi-bin/core/doctype/letter_head/letter_head.txt','1311340897'),('cgi-bin/core/doctype/module_def/module_def.txt','1311340897'),('cgi-bin/core/doctype/module_def_item/module_def_item.txt','1311340897'),('cgi-bin/core/doctype/module_def_role/module_def_role.txt','1311340897'),('cgi-bin/core/doctype/page/page.txt','1311340897'),('cgi-bin/core/doctype/page_role/page_role.txt','1311340897'),('cgi-bin/core/doctype/page_template/page_template.txt','1311340897'),('cgi-bin/core/doctype/print_format/print_format.txt','1311340897'),('cgi-bin/core/doctype/profile/profile.txt','1311340897'),('cgi-bin/core/doctype/property_setter/property_setter.txt','1311340897'),('cgi-bin/core/doctype/role/role.txt','1311340897'),('cgi-bin/core/doctype/sandbox/my_trigger.sql','1311338267'),('cgi-bin/core/doctype/sandbox/sandbox.txt','1311340897'),('cgi-bin/core/doctype/search_criteria/search_criteria.txt','1311340897'),('cgi-bin/core/doctype/stylesheet/stylesheet.txt','1311340897'),('cgi-bin/core/doctype/system_console/system_console.txt','1311340897'),('cgi-bin/core/doctype/table_mapper_detail/table_mapper_detail.txt','1311340897'),('cgi-bin/core/doctype/tag/tag.txt','1311340897'),('cgi-bin/core/doctype/userrole/userrole.txt','1311340897'),('cgi-bin/core/Module Def/Core/Core.txt','1311340843'),('cgi-bin/core/page/login_page/login_page.txt','1311341311'),('cgi-bin/core/Role/Administrator/Administrator.txt','1310636182'),('cgi-bin/core/Role/All/All.txt','1310636182'),('cgi-bin/core/Role/Guest/Guest.txt','1310636182');
/*!40000 ALTER TABLE `__file_timestamp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabComment Widget Record`
--

DROP TABLE IF EXISTS `tabComment Widget Record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabComment Widget Record` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `comment` text,
  `comment_date` date DEFAULT NULL,
  `comment_by` varchar(180) DEFAULT NULL,
  `post_topic` varchar(180) DEFAULT NULL,
  `comment_docname` varchar(180) DEFAULT NULL,
  `comment_time` varchar(180) DEFAULT NULL,
  `comment_doctype` varchar(180) DEFAULT NULL,
  `comment_by_fullname` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabComment Widget Record`
--

LOCK TABLES `tabComment Widget Record` WRITE;
/*!40000 ALTER TABLE `tabComment Widget Record` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabComment Widget Record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCustom Field`
--

DROP TABLE IF EXISTS `tabCustom Field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCustom Field` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `insert_after` varchar(180) DEFAULT NULL,
  `print_hide` int(1) DEFAULT NULL,
  `permlevel` int(11) DEFAULT '0',
  `trash_reason` text,
  `default` text,
  `allow_on_submit` int(1) DEFAULT NULL,
  `no_copy` int(1) DEFAULT NULL,
  `label` varchar(180) DEFAULT NULL,
  `width` varchar(180) DEFAULT NULL,
  `fieldname` varchar(180) DEFAULT NULL,
  `fieldtype` varchar(180) DEFAULT NULL,
  `reqd` int(1) DEFAULT NULL,
  `dt` varchar(180) DEFAULT NULL,
  `in_filter` int(1) DEFAULT NULL,
  `options` text,
  `report_hide` int(1) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCustom Field`
--

LOCK TABLES `tabCustom Field` WRITE;
/*!40000 ALTER TABLE `tabCustom Field` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCustom Field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCustom Script`
--

DROP TABLE IF EXISTS `tabCustom Script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCustom Script` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `dt` varchar(180) DEFAULT NULL,
  `script` text,
  `script_type` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCustom Script`
--

LOCK TABLES `tabCustom Script` WRITE;
/*!40000 ALTER TABLE `tabCustom Script` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCustom Script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDefault Home Page`
--

DROP TABLE IF EXISTS `tabDefault Home Page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDefault Home Page` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `home_page` varchar(180) DEFAULT NULL,
  `role` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDefault Home Page`
--

LOCK TABLES `tabDefault Home Page` WRITE;
/*!40000 ALTER TABLE `tabDefault Home Page` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDefault Home Page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDefaultValue`
--

DROP TABLE IF EXISTS `tabDefaultValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDefaultValue` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `defvalue` text,
  `defkey` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDefaultValue`
--

LOCK TABLES `tabDefaultValue` WRITE;
/*!40000 ALTER TABLE `tabDefaultValue` DISABLE KEYS */;
INSERT INTO `tabDefaultValue` VALUES ('DEF000001','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Guest','defaults','Role',1,'1','hide_webnotes_toolbar'),('DEF000002','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Guest','defaults','Role',2,'1','hide_sidebars');
/*!40000 ALTER TABLE `tabDefaultValue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocField`
--

DROP TABLE IF EXISTS `tabDocField`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocField` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `fieldname` varchar(180) DEFAULT NULL,
  `label` varchar(180) DEFAULT NULL,
  `oldfieldname` varchar(180) DEFAULT NULL,
  `fieldtype` varchar(180) DEFAULT NULL,
  `oldfieldtype` varchar(180) DEFAULT NULL,
  `options` text,
  `search_index` int(1) DEFAULT NULL,
  `hidden` int(1) DEFAULT NULL,
  `print_hide` int(1) DEFAULT NULL,
  `report_hide` int(1) DEFAULT NULL,
  `reqd` int(1) DEFAULT NULL,
  `no_copy` int(1) DEFAULT NULL,
  `allow_on_submit` int(1) DEFAULT NULL,
  `trigger` varchar(180) DEFAULT NULL,
  `depends_on` varchar(180) DEFAULT NULL,
  `permlevel` int(11) DEFAULT '0',
  `width` varchar(180) DEFAULT NULL,
  `default` text,
  `description` text,
  `colour` varchar(180) DEFAULT NULL,
  `icon` varchar(180) DEFAULT NULL,
  `in_filter` int(1) DEFAULT NULL,
  `no_column` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `label` (`label`),
  KEY `fieldtype` (`fieldtype`),
  KEY `fieldname` (`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocField`
--

LOCK TABLES `tabDocField` WRITE;
/*!40000 ALTER TABLE `tabDocField` DISABLE KEYS */;
INSERT INTO `tabDocField` VALUES ('000000004','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',1,NULL,'Options',NULL,'Section Break','Section Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000005','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',2,NULL,'Settings',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('000000006','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',3,'module','Module','module','Link','Link','Module Def',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000007','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',4,'version','Version','version','Int','Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000008','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',5,'name','Name','name','Data','Data',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000009','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',6,'autoname','Auto Name','autoname','Data','Data',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000010','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',7,'owner','Owner','owner','Link','Link',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000011','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',8,'name_case','Name Case','name_case','Select','Select','\nTitle Case\nUPPER CASE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000012','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',9,'search_fields','Search Fields','search_fields','Data','Data',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000013','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',10,'subject','Subject',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Subject will appear as a string in the docbrowser: eg.\n[%(status)s] %(description)s\nIf it is a JS Expression, use \"eval:\"','White:FFF',NULL,NULL,NULL),('000000014','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',11,'tag_fields','tag_fields',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Fields separated by (,) that will be set as tags','White:FFF',NULL,NULL,NULL),('000000015','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',12,'istable','Is Table','istable','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000016','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',13,'read_only','Not In Search','read_only','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000017','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',14,'in_create','Not In Create','in_create','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000018','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',15,'issingle','Is Single','issingle','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,'Client',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000019','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',16,'read_only_onload','Show Print First','read_only_onload','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000020','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',17,'show_in_menu','Show In Pages','show_in_menu','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000021','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',18,'document_type','Document Type','document_type','Select','Select','\nMaster\nTransaction\nSystem\nOther',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000022','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',19,NULL,'Display',NULL,'Column Break','Column Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('000000023','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',20,'is_transaction_doc','Is Transaction Doc','is_transaction_doc','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000024','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',21,'use_template','Use Template','use_template','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000025','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',22,'print_outline','Print Outline','print_outline','Select','Select','\nNo\nYes',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000026','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',23,'allow_print','Hide Print','allow_print','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000027','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',24,'allow_email','Hide Email','allow_email','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000028','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',25,'in_dialog','In Dialog','in_dialog','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000029','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',26,'allow_copy','Hide Copy','allow_copy','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000030','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',27,'hide_toolbar','Hide Toolbar','hide_toolbar','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000031','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',28,'hide_heading','Hide Heading','hide_heading','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000032','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',29,'allow_attach','Allow Attach','allow_attach','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Client',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000033','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',30,'max_attachments','Max Attachments','max_attachments','Int','Int',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000034','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',31,'allow_rename','Allow Rename','allow_rename','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000035','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',32,'section_style','Section Style','section_style','Select','Select','Simple\nPaged\nTabbed\nTray',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000036','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',33,'colour','Colour','colour','Select','Select','White:FFF\nLight Blue:DEF\nLight Green:DFE\nPeach:FEF3C5\nPink:FEF2EA\nLilac:FDEAFE\nAqua:EAFEFA',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000037','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',34,'smallicon','Small Icon','smallicon','Select','Select','\naccept.png\nadd.png\napplication.png\nbell.png\nbox.png\ncalendar.png\ncalculator.png\ncancel.png\ncart.png\ncd.png\nchart_bar.png\nclock.png\ncoins.png\ncomputer.png\ncontroller.png\ndisk.png\nemail.png\nerror.png\nfolder.png\ngroup.png\nhouse.png\nimages.png\nlock_open.png\nlock.png\nlorry.png\nmagnifier.png\nmap.png\nmoney.png\nnew.png\npage.png\nprinter.png\nreport.png\nserver.png\nshield.png\ntable.png\nuser.png',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000038','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',35,NULL,'Permissions',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000039','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',36,NULL,'Roles and Permissions',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'70%',NULL,NULL,NULL,NULL,NULL,NULL),('000000040','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',37,'permissions','Permissions','permissions','Table','Table','DocPerm',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'White:FFF',NULL,NULL,NULL),('000000041','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',38,'allow_trash','Allow Trash','allow_trash','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000042','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',39,NULL,'Print Formats',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'30%',NULL,NULL,NULL,NULL,NULL,NULL),('000000043','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',40,'formats','Formats','formats','Table','Table','DocFormat',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000044','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',41,NULL,'Fields',NULL,'Section Break','Section Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000045','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',42,NULL,'Document Fields',NULL,'Column Break','Column Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000046','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',43,'fields','Fields','fields','Table','Table','DocField',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000047','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',44,NULL,'Description',NULL,'Section Break','Section Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('000000048','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','fields','DocType',45,'description','Description','description','Text','Text',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00001','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',1,'label','Label','label','Data','Data',NULL,1,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00002','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',2,'fieldtype','Type','fieldtype','Select','Select','Data\nSelect\nText\nSmall Text\nText Editor\nLink\nInt\nDate\nTime\nCurrency\nTable\nFloat\nCheck\nSection Break\nColumn Break\nButton\nRead Only\nCode\nHTML\nImage\nBlob\nPassword',1,0,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00003','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',3,'fieldname','Name','fieldname','Data','Data',NULL,1,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00004','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',4,'options','Options','options','Text','Text',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,'For Links, enter the DocType as range\nFor Select, enter list of Options separated by comma',NULL,NULL,NULL,NULL),('FL00005','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',5,'permlevel','Perm Level','permlevel','Int','Int',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,'0',NULL,NULL,NULL,NULL,NULL),('FL00006','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',6,'width','Width','width','Data','Data',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'50px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00007','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',7,'reqd','Reqd','reqd','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'50px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00008','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',8,'search_index','Index','search_index','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'50px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00009','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',9,'in_filter','In Filter','in_filter','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00010','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',10,'hidden','Hidden','hidden','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'50px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00011','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',11,'no_column','No Column',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00012','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',12,'print_hide','Print Hide','print_hide','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00013','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',13,'no_copy','No Copy','no_copy','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00014','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',14,'report_hide','Report Hide','report_hide','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'White:FFF',NULL,NULL,NULL),('FL00015','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',15,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00016','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',16,'depends_on','Depends On','depends_on','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00017','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',17,'description','Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00018','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',18,'trigger','Trigger','trigger','Select','Select','\nClient\nServer',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00019','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',19,'default','Default','default','Text','Text',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00020','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',20,'colour','Colour','colour','Select','Select','White:FFF\nLight Blue:DEF\nLight Green:DFE\nPeach:FEF3C5\nPink:FEF2EA\nLilac:FDEAFE\nAqua:EAFEFA',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00021','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',21,'icon','Icon','icon','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00022','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',22,'oldfieldname',NULL,'oldfieldname','Data','Data',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00023','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',23,'oldfieldtype',NULL,'oldfieldtype','Data','Data',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00024','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','fields','DocType',23,'oldfieldtype',NULL,'oldfieldtype','Data','Data',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00025','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',1,'permlevel','Level','permlevel','Int','Int',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'40px','0',NULL,NULL,NULL,NULL,NULL),('FL00026','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',2,'role','Role','role','Link','Link','Role',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'150px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00027','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',3,'read','Read','read','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'32px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00028','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',4,'write','Write','write','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'32px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00029','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',5,'create','Create','create','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'32px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00030','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',6,'submit','Submit','submit','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'32px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00031','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',7,'cancel','Cancel','cancel','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'32px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00032','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',8,'execute','Execute','execute','Check','Check',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'32px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00033','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',9,'amend','Amend','amend','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00034','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'DocPerm','fields','DocType',10,'match','Match','match','Data','Data',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00035','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',1,'comment','Comment','comment','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00036','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',2,'comment_by','Comment By','comment_by','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00037','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',3,'comment_by_fullname','Comment By Fullname','comment_by_fullname','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00038','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',4,'comment_date','Comment Date','comment_date','Date','Date',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00039','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',5,'comment_time','Comment Time','comment_time','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00040','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',6,'comment_doctype','Comment Doctype','comment_doctype','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00041','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',7,'comment_docname','Comment Docname','comment_docname','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00042','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','fields','DocType',8,'post_topic','Post Topic','post_topic','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00043','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',1,NULL,'General',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00044','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',2,'date_format','Date Format',NULL,'Select',NULL,'yyyy-mm-dd\ndd-mm-yyyy\ndd/mm/yyyy\nmm/dd/yyyy\nmm-dd-yyyy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00045','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',3,'currency_format','Currency Format',NULL,'Select',NULL,'Millions\nLacs',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00046','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',4,'password_expiry_days','Password Expires in (days)',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00047','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',5,'session_expiry','Session Expires in (time)',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Format: hh:mm example for one hour expiry set as 01:00. \nMax expiry will be 72 hours. Default is 24 hours','White:FFF',NULL,NULL,NULL),('FL00048','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',6,'sync_with_gateway','Sync with Gateway',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00049','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',7,'title','Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00050','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',8,'account_id','Account Id',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00051','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',9,'company_name','Company Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00052','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',10,'industry','Industry',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00053','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',11,'time_zone','Time Zone',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00054','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',12,'country','Country',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00055','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',13,'total_sms_sent','Total SMS Sent',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00056','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',14,NULL,'Home Pages',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00057','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',15,'default_home_pages','Default Home Pages',NULL,'Table',NULL,'Default Home Page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00058','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',16,'home_page','Home Page',NULL,'Link',NULL,'Page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00059','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',17,NULL,'Startup',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00060','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',18,'startup_code','Startup Code (JS)',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00061','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',19,'startup_css','Startup CSS',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00062','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',20,NULL,'Display',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00063','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',21,NULL,'Display Options',NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'100%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00064','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',22,'page_width','Page WIdth',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Default page width is auto',NULL,NULL,NULL,NULL),('FL00065','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',23,'hide_webnotes_toolbar','Hide WebNotes Toolbar',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00066','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',24,'background_color','Background Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00067','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',25,NULL,'Header / Footer',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00068','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',26,'header_height','Header Height',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Default header height is 40px',NULL,NULL,NULL,NULL),('FL00069','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',27,'client_name','Header HTML',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00070','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',28,'footer_height','Footer Height',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00071','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',29,'footer_html','Footer HTML',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00072','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','fields','DocType',30,'letter_head','Letter Head',NULL,'Text',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00073','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',31,'client_logo','Client Logo',NULL,'Link',NULL,'File',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00074','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',32,NULL,'Mail Server',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00075','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',33,'support_email_id','Support Email Id',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Enter Email Id to receive Error Report sent by users.\nE.g.: support@iwebnotes.com',NULL,NULL,NULL,NULL),('FL00076','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',34,'letter_head_image','Letter Head Image',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00077','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',35,'auto_email_id','Auto Email Id',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'automail@notesandreports.com',NULL,NULL,NULL,NULL,NULL),('FL00078','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',36,'outgoing_mail_server','Outgoing Mail Server',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'e.g. mail.webnotestech.com','White:FFF',NULL,NULL,NULL),('FL00079','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',37,'mail_port','Mail Port',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00080','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',38,'use_ssl','Use SSL',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00081','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',39,'mail_login','Login Id',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00082','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',40,'mail_password','Mail Password',NULL,'Password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00083','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',41,'mail_footer','Mail Footer',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00084','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',42,NULL,'Defaults',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00085','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',43,'system_defaults','System Defaults',NULL,'Table',NULL,'DefaultValue',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00086','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',44,NULL,'Sidebars',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00087','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',45,'left_sidebar_width','Left Sidebar Width',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'To hide the left sidebar, leave this blank or 0',NULL,NULL,NULL,NULL),('FL00088','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',46,'right_sidebar_width','Right Sidebar Width',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'To hide the right sidebar, leave this blank or 0',NULL,NULL,NULL,NULL),('FL00089','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',47,NULL,'Test Script',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00090','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',48,NULL,'Execute Local',NULL,'Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00091','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',49,NULL,'Execute (Careful!)',NULL,'Button',NULL,'execute_test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'150px',NULL,NULL,NULL,'accept.png',NULL,NULL),('FL00092','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Control Panel','fields','DocType',50,'test_code','Test Code',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00093','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',1,NULL,'Details',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00094','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',2,'trash_reason','Trash Reason','trash_reason','Small Text','Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00095','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',3,'dt','Document','dt','Link','Link','DocType',NULL,NULL,NULL,NULL,1,NULL,NULL,'Client',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00096','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',4,'label','Label','label','Data','Data',NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00097','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',5,NULL,'Label Help',NULL,'HTML','HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00098','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',6,'fieldtype','Field Type','fieldtype','Select','Select','\nButton\nCheck\nColumn Break\nCurrency\nData\nDate\nFloat\nHTML\nInt\nLink\nRead Only\nSection Break\nSelect\nSmall Text\nText\nText Editor\nTime',NULL,NULL,NULL,NULL,1,NULL,NULL,'Client',NULL,0,NULL,NULL,NULL,'White:FFF',NULL,NULL,NULL),('FL00099','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',7,NULL,'Options Help',NULL,'HTML','HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00100','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',8,'options','Options','options','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00101','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',9,'description','Field Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00102','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',10,NULL,'Properties',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00103','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',11,'insert_after','Insert After','insert_after','Select','Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Client',NULL,0,NULL,NULL,'Select the label after which you want to insert new field.','White:FFF',NULL,NULL,NULL),('FL00104','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',12,'default','Default Value','default','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00105','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',13,'fieldname','Fieldname','fieldname','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00106','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',14,'width','Width','width','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00107','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',15,'reqd','Is Mandatory Field','reqd','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00108','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',16,'in_filter','In Report Filter','in_filter','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00109','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',17,'no_copy','No Copy','no_copy','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00110','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',18,'print_hide','Print Hide','print_hide','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00111','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',19,'report_hide','Report Hide','report_hide','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00112','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',20,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00113','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','fields','DocType',21,'permlevel','Permission Level','permlevel','Int','Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'0',NULL,NULL,NULL,NULL,NULL),('FL00114','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Script','fields','DocType',1,'dt','DocType','dt','Link','Link','DocType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00115','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Script','fields','DocType',2,'script_type','Script Type','script_type','Select','Select','Server\nClient',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00116','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Script','fields','DocType',3,'script','Script','script','Code','Code','Script',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00117','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Default Home Page','fields','DocType',1,'role','Role','role','Link','Link','Role',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00118','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Default Home Page','fields','DocType',2,'home_page','Home Page','home_page','Link','Link','Page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00119','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DefaultValue','fields','DocType',1,'defkey','Key','defkey','Data','Data',NULL,0,0,NULL,NULL,1,NULL,NULL,NULL,NULL,0,'200px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00120','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DefaultValue','fields','DocType',2,'defvalue','Value','defvalue','Text','Text',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'200px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00121','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocFormat','fields','DocType',1,'format','Format','format','Link','Link','Print Format',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00122','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocTrigger','fields','DocType',1,'doc_type','Doc Type',NULL,'Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00123','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocTrigger','fields','DocType',2,'doc_name','Doc Name',NULL,'Data',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00124','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocTrigger','fields','DocType',3,'event_name','Event Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00125','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocTrigger','fields','DocType',4,'method','Method',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00126','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocType Label','fields','DocType',1,'dt','Select DocType','dt','Select','Select','link:DocType',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00127','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocType Label','fields','DocType',2,'dt_label','DocType Label','dt_label','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00128','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','fields','DocType',1,'module','Module','module','Select','Select','link:Module Def',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00129','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','fields','DocType',2,'from_doctype','From DocType','from_doctype','Select','Select','link:DocType',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00130','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','fields','DocType',3,'to_doctype','To DocType','to_doctype','Select','Select','link:DocType',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00131','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','fields','DocType',4,'ref_doc_submitted','Ref Doc should be submitted?','ref_doc_submitted','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00132','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','fields','DocType',5,'field_mapper_details','Field Mapper Details','field_mapper_details','Table','Table','Field Mapper Detail',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00133','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','fields','DocType',6,'table_mapper_details','Table Mapper Details','table_mapper_details','Table','Table','Table Mapper Detail',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00134','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',1,NULL,'Details',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00135','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',2,NULL,'Intro HTML',NULL,'HTML','HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00136','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',3,'event_date','Event Date','event_date','Date','Date',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00137','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',4,'event_hour','Event Time','event_hour','Time','Time',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00138','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',5,'event_name','Event Name','event_name','Data','Data',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00139','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',6,'description','Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00140','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',7,'notes','Notes','notes','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00141','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',8,'event_type','Event Type','event_type','Select','Select','Private\nPublic\nCancel',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00142','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',9,NULL,'Participants',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00143','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',10,NULL,'Individuals',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00144','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',11,'event_individuals','Event Individuals','event_individuals','Table','Table','Event User',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00145','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',12,NULL,'Groups',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00146','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',13,'event_roles','Event Roles','event_roles','Table','Table','Event Role',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00147','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',14,'ref_type','Ref Type','ref_type','Data','Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00148','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','fields','DocType',15,'ref_name','Ref Name','ref_name','Data','Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00149','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event Role','fields','DocType',1,'role','Role','role','Link','Link','Role',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00150','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event User','fields','DocType',1,'person','Person','person','Select','Select','link:Profile',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00151','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Field Mapper Detail','fields','DocType',1,'from_field','From Field','from_field','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'180px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00152','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Field Mapper Detail','fields','DocType',2,'to_field','To Field','to_field','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'180px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00153','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Field Mapper Detail','fields','DocType',3,'match_id','Match Id','match_id','Int','Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50px','0',NULL,NULL,NULL,NULL,NULL),('FL00154','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Field Mapper Detail','fields','DocType',4,'map','Map','map','Select','Select','Yes\nNo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00155','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Field Mapper Detail','fields','DocType',5,'checking_operator','Checking Operator (To Fld, Operator, From Fld)','checking_operator','Select','Select','\n=\n>\n>=\n<\n<=',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'180px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00156','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',1,'file_name','File Name','file_name','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00157','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',2,'description','Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00158','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',3,'mime_type','MIME Type','mime_type','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00159','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',4,'type','Type','type','Select','Select','\nImage\nDocument\nSpreadsheet\nPresentation\nOther',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00160','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',5,'file_group','File Group','file_group','Link','Link','File Group',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00161','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',6,'file_list','File List','file_list','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00162','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',7,'shared_with','Shared With','shared_with','Text','Text',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00163','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',8,'can_edit','Can Edit','can_edit','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00164','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','fields','DocType',9,'can_view','Can View','can_view','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00165','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File Data','fields','DocType',1,'file_name','File Name','file_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00166','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File Data','fields','DocType',2,'module','Module','module','Link','Link','Module Def',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00167','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File Data','fields','DocType',3,'blob_content','Blob Content','blob_content','Blob','Blob',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00168','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'File Group','fields','DocType',1,'group_name','Group Name','group_name','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00169','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'File Group','fields','DocType',2,'parent_group','Parent Group','parent_group','Link','Link','File Group',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00170','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'File Group','fields','DocType',3,'description','Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00171','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'File Group','fields','DocType',4,'is_parent','Is Parent','is_parent','Check','Check',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00172','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'File Group','fields','DocType',5,'shared_with','Shared With','shared_with','Text','Text',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00173','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'File Group','fields','DocType',6,'can_edit','Can Edit','can_edit','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00174','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'File Group','fields','DocType',7,'can_view','Can View','can_view','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00175','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','fields','DocType',1,'letter_head_name','Letter Head Name','letter_head_name','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL),('FL00176','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','fields','DocType',2,'disabled','Disabled','disabled','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00177','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','fields','DocType',3,'is_default','Is Default','is_default','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Check this to make this the default letter head in all prints',NULL,NULL,NULL,NULL),('FL00178','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','fields','DocType',4,'set_from_image','Set From Image',NULL,'Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Client',NULL,0,NULL,NULL,'To update your HTML from attachment, click here',NULL,NULL,NULL,NULL),('FL00179','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','fields','DocType',5,'content','Content','content','Code','Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'Your letter head content in HTML.',NULL,NULL,NULL,NULL),('FL00180','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','fields','DocType',6,'url','URL',NULL,'Data',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00181','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','fields','DocType',7,'file_list','File LIst','file_list','Text','Text',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00182','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',1,'trash_reason','Trash Reason','trash_reason','Small Text','Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00183','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',2,NULL,'Module Details',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00184','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',3,'disabled','Disabled','disabled','Select','Select','No\nYes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00185','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',4,'module_name','Module Name','module_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00186','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',5,'module_label','Module Label','module_label','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00187','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',6,'doctype_list','DocType List','doctype_list','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00188','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',7,'module_page','Module Page','module_page','Link','Link','Page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00189','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',8,'module_desc','Module Description','module_desc','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00190','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',9,'module_icon','Module Icon','module_icon','Select','Select','\naccept.png\nadd.png\nadd_to_shopping_cart.png\napple.png\nattachment.png\nback.png\nbooks.png\nbox.png\nbrush.png\ncalculator.png\ncalendar.png\ncamera.png\ncard.png\nchart.png\nchart_down.png\nchart_up.png\nchess.png\nclock.png\ncloud_comment.png\ncoffee.png\ncomment.png\ncut.png\ndatabase.png\ndelete.png\ndollar_currency_sign.png\ndown.png\ndownload.png\nemail.png\nempty_calendar.png\neuro_currency_sign.png\nfavorite.png\nfind.png\nfolder.png\nfull_screen.png\ngames.png\nglobe.png\ngreen_flag.png\nheart.png\nhelp.png\nhome.png\nid_card.png\ninfo.png\ninsert_to_shopping_cart.png\niphone.png\nipod.png\nkey.png\nkeyboard.png\nlaptop.png\nlight_bulb.png\nlock.png\nmagnet.png\nmail.png\nmail_receive.png\nmail_search.png\nmail_send.png\nmap.png\nmap_blue.png\nmap_red.png\nmegaphone.png\nmicrophone.png\nmobile_phone.png\nmonitor.png\nmouse.png\nmusic_note.png\nnews.png\nnext.png\npage.png\npencil.png\npicture.png\npie_chart.png\nprint.png\nprocess.png\npromo_green.png\npromo_orange.png\npromo_red.png\npromo_turquoise.png\npromo_violet.png\npromotion.png\npromotion_new.png\nprotection.png\npuzzle.png\nred_flag.png\nrefresh.png\nremove.png\nremove_from_shopping_cart.png\nrss.png\nsave.png\nschool_board.png\nsearch.png\nsecurity.png\nshopping_cart.png\nshopping_cart_accept.png\nshut_down.png\nsms.png\nsound.png\nstar_empty.png\nstar_full.png\nstar_half_full.png\nsterling_pound_currency_sign.png\ntag.png\ntarget.png\ntelephone.png\ntelevision.png\ntoolbox.png\ntools.png\ntrash.png\nunlock.png\nup.png\nupload.png\nuser.png\nusers.png\nvideo.png\nvideo_camera.png\nwarning.png\nwebcam.png\nwired.png\nwireless.png\nyen_currency_sign.png\nzoom_in.png\nzoom_out.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00191','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',10,'module_seq','Module Sequence','module_seq','Int','Int',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL),('FL00192','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',11,NULL,'Item List',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00193','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',12,'items','Items','items','Table','Table','Module Def Item',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00194','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',13,NULL,'Role List',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00195','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',14,'roles','Roles','roles','Table','Table','Module Def Role',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00196','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',15,'file_list','File List','file_list','Text','Text',NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00197','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',16,NULL,'Widget Script',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00198','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',17,'widget_code','Widget Code','widget_code','Code','Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00199','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','fields','DocType',18,'is_hidden','Is Hidden','is_hidden','Select','Select','No\nYes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00200','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',1,'doc_type','Doc Type','doc_type','Select','Select','Forms\nPages\nReports\nSeparator\nMore Reports\nSetup Forms\nSetup Pages\nSingle DocType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00201','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',2,'doc_name','Doc Name','doc_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00202','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',3,'display_name','Display Name','display_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00203','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',4,'icon','Icon','icon','Select','Select','\naccept.gif\nadd.gif\napplication.gif\narrow_down.gif\narrow_left.gif\narrow_right.gif\narrow_up.gif\ncalculator.gif\ncalendar.gif\ncancel.gif\nchart_bar.gif\nclose.gif\ncomments.gif\ndisk.gif\ndown-arrow.gif\nemail.gif\nerror.gif\nfolder.gif\ngroup.gif\nhelp.gif\nicon-recommend.gif\nlightbulb.gif\nmagnifier.gif\nminus.gif\nnote.gif\npage.gif\npage_add.gif\npage_copy.gif\npage_excel.gif\npage_refresh.gif\npaperclip.gif\nplus.gif\nprinter.gif\nresultset_first.gif\nresultset_last.gif\nresultset_next.gif\nresultset_previous.gif\nsort_asc.gif\nsort_desc.gif\nstar.gif\ntable.gif\ntable_row_delete.gif\ntable_row_insert.gif\nuser.gif\nwrench.gif',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00204','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',5,'description','Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00205','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',6,'fields','Fields','fields','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00206','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',7,'click_function','Click Function','click_function','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00207','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Item','fields','DocType',8,'hide','Hide','hide','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00208','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def Role','fields','DocType',1,'role','Role','role','Link','Link','Role',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00209','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',1,NULL,'Page HTML',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00210','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',2,'page_name','Page Name','page_name','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00211','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',3,'module','Module','module','Select','Select','link:Module Def',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00212','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',4,'standard','Standard','standard','Select','Select','\nYes\nNo',1,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00213','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',5,NULL,'Help HTML',NULL,'HTML','HTML','<div class=\"comment\" style=\"margin: 8px 0px\">To add images, use <b>$image(<i>filename</i>)</b><br>Where file name is the ID or Name of the File record</div>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00214','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',6,'content','Content','content','Text Editor','Text Editor',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00215','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',7,NULL,'Client Script',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00216','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',8,'script','Script','script','Code','Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00217','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',9,NULL,'Menu Display',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00218','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',10,NULL,'Roles that can access',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00219','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',11,NULL,'CSS Style',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00220','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',12,'style','Style','style','Code','Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00221','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',13,NULL,'Static HTML',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00222','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',14,'static_content','Static Content','static_content','Code','Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00223','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',15,NULL,'Permissions',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00224','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',16,'show_in_menu','Show In Start','show_in_menu','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Client',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00225','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',17,'parent_node','Parent Node','parent_node','Data','Data',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00226','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',18,NULL,'Parent HTML',NULL,'HTML','HTML','<div style=\"color: #888; padding: 4px; padding-bottom: 16px;\">Write in the name of the parent (Page / DocType) under which you want this Page to appear in the Menu.</div>',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00227','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','fields','DocType',19,'icon','Icon','icon','Select','Select','\naccept.png\nadd.png\napplication.png\nbell.png\nbox.png\ncalendar.png\ncalculator.png\ncancel.png\ncart.png\ncd.png\nchart_bar.png\nclock.png\ncoins.png\ncomputer.png\ncontroller.png\ndisk.png\nemail.png\nerror.png\nfolder.png\ngroup.png\nhouse.png\nimages.png\nlock_open.png\nlock.png\nlorry.png\nmagnifier.png\nmap.png\nmoney.png\nnew.png\npage.png\nprinter.png\nreport.png\nserver.png\nshield.png\ntable.png\nuser.png',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00228','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page','fields','DocType',20,'menu_index','Menu Index','menu_index','Int','Int',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00229','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page','fields','DocType',21,NULL,'Menu HTML',NULL,'HTML','HTML','<div style=\"color: #888; padding: 4px; padding-bottom: 16px;\">Select the order in which this Page will be displayed in the menu: 0 is Highest</div>',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00230','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page','fields','DocType',22,'roles','Roles','roles','Table','Table','Page Role',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00231','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page','fields','DocType',23,NULL,'Menu Options',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00232','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page Role','fields','DocType',1,'role','Role','role','Link','Link','Role',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00233','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page Template','fields','DocType',1,'template_name','Template Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00234','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page Template','fields','DocType',2,'module','Module',NULL,'Link',NULL,'Module Def',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00235','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Page Template','fields','DocType',3,'template','Template',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00236','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Print Format','fields','DocType',1,'module','Module','module','Select','Select','link:Module Def',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00237','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Print Format','fields','DocType',2,'html','HTML','html','Code','Text Editor',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00238','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Print Format','fields','DocType',3,'standard','Standard','standard','Select','Select','\nYes\nNo',1,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00239','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',1,NULL,'Details',NULL,'Section Break','Section Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00240','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',2,NULL,'Picture',NULL,'Column Break','Column Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00241','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',3,NULL,'Profile Picture',NULL,'Image','Image',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00242','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',4,NULL,'Contact',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00243','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',5,'enabled','Enabled','enabled','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'1',NULL,NULL,NULL,NULL,NULL),('FL00244','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',6,'send_email_invite','Send Email Invite','send_email_invite','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'1',NULL,NULL,NULL,NULL,NULL),('FL00245','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',8,'recent_documents','Recent Documents','recent_documents','Text','Text',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00246','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',9,'first_name','First Name','first_name','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00247','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',10,'middle_name','Middle Name (Optional)','middle_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00248','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',11,'last_name','Last Name','last_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00249','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',12,'email','Email','email','Data','Data',NULL,0,0,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00250','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',13,'birth_date','Birth Date','birth_date','Date','Date',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00251','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',14,'gender','Gender','gender','Select','Select','\nMale\nFemale',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00252','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',15,'occupation','Designation','occupation','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00253','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',16,'bio','Bio','bio','Text','Text',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00254','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',17,'interests','Interests','interests','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00255','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',18,'activities','Activities','activities','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00256','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',19,'messanger_status','Messanger Status','messanger_status','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00257','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',20,'home_phone','Home Phone','home_phone','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00258','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',21,'office_phone','Office Phone','office_phone','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00259','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',22,'extension','Extension','extension','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00260','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',23,'cell_no','Cell No','cell_no','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00261','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',24,'user_type','User Type','user_type','Select','Select','\nSystem User\nPartner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00262','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',25,'last_login','Last Login','last_login','Read Only','Read Only',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00263','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',26,'last_ip','Last IP','last_ip','Read Only','Read Only',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00264','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',27,NULL,'Address',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00265','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',28,'line_1','Line 1','line_1','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00266','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',29,'line_2','Line 2','line_2','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00267','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',30,'city','City / Town','city','Data','Data',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00268','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',31,'district','District','district','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00269','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',32,'state','State','state','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00270','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',33,'country','Country','country','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00271','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',34,'pin','Pin','pin','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00272','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',35,NULL,'User Role',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00273','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',36,NULL,'Roles',NULL,'Section Break','Section Break',NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00274','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',37,'userroles','User Roles','userroles','Table','Table','UserRole',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,1,NULL,'Simple',NULL,'White:FFF',NULL,NULL,NULL),('FL00275','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',38,NULL,'System Defaults',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00276','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',39,'defaults','Defaults','defaults','Table','Table','DefaultValue',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,1,NULL,'Simple',NULL,'White:FFF',NULL,NULL,NULL),('FL00277','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',40,NULL,'Password',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00278','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',41,NULL,'Change Your Password',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'50%',NULL,NULL,NULL,NULL,NULL,NULL),('FL00279','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',42,'password','Current Password','password','Data','Data',NULL,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'Pink:FEF2EA',NULL,NULL,NULL),('FL00280','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',43,'new_password','New Password','new_password','Password','Password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00281','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',44,'retype_new_password','Retype New Password','retype_new_password','Password','Password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00282','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',45,'password_last_updated','Password Last Updated','password_last_updated','Date','Date',NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00283','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',46,NULL,'Change Password',NULL,'Button','Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Client',NULL,1,'120px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00284','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',47,NULL,'Attachment',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00285','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',48,'social_points','Social Points','social_points','Int','Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'0',NULL,NULL,NULL,NULL,NULL),('FL00286','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',49,'social_badge','Social Badge','social_badge','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00287','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',50,'avatar','Avatar','avatar','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00288','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',51,NULL,'Attachment HTML',NULL,'HTML','HTML','First attachment must be the picture',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00289','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',52,'file_list','File List','file_list','Text','Text',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00290','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','fields','DocType',53,'fiscal_year','Fiscal Year','fiscal_year','Select','Select','link:Fiscal Year',NULL,1,1,1,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL),('FL00291','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',1,'doctype_or_field','DocType or Field',NULL,'Select',NULL,'\nDocField\nDocType',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'eval:doc.__islocal',0,NULL,NULL,NULL,NULL,NULL,NULL,0),('FL00292','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',2,'select_doctype','Select DocType',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.doctype_or_field && doc.__islocal',0,NULL,NULL,NULL,'White:FFF',NULL,NULL,0),('FL00293','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',3,'select_item','Select Field',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'eval:doc.doctype_or_field==\'DocField\' && doc.__islocal',0,NULL,NULL,NULL,'White:FFF',NULL,NULL,0),('FL00294','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',4,'select_property','Select Property',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'eval:doc.doctype_or_field && doc.__islocal',0,NULL,NULL,NULL,NULL,NULL,NULL,0),('FL00295','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',5,'value','Set Value',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'doc_name',0,NULL,NULL,'New value to be set','White:FFF',NULL,NULL,NULL),('FL00296','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',6,NULL,NULL,NULL,'Column Break',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00297','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',7,'doc_type','DocType',NULL,'Read Only',NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'White:FFF',NULL,0,0),('FL00298','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',8,'doc_name','Field ID',NULL,'Read Only',NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,'eval:doc.doctype_or_field==\'DocField\'',0,NULL,NULL,'ID (name) of the entity whose property is to be set','White:FFF',NULL,0,NULL),('FL00299','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',9,'property','Property',NULL,'Read Only',NULL,NULL,1,NULL,NULL,NULL,1,NULL,NULL,NULL,'eval:doc.doc_name && doc.__islocal',0,NULL,NULL,NULL,'White:FFF',NULL,0,NULL),('FL00300','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',10,'property_type','Property Type',NULL,'Read Only',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'doc_name',0,NULL,NULL,NULL,'White:FFF',NULL,NULL,0),('FL00301','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','fields','DocType',11,'default_value','Default Value',NULL,'Read Only',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'doc_name',0,NULL,NULL,NULL,'White:FFF',NULL,NULL,0),('FL00302','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Role','fields','DocType',1,'module','Module','module','Select','Select','link:Module Def',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00303','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Role','fields','DocType',2,'role_name','Role Name','role_name','Data','Data',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00304','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Role','fields','DocType',3,'defaults','Defaults','defaults','Table','Table','DefaultValue',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00305','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Sandbox','fields','DocType',1,'test_data','Test Data',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00306','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Sandbox','fields','DocType',2,'test_link','Test Link',NULL,'Link',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00307','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Sandbox','fields','DocType',3,'test_text','Test Text',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00308','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Sandbox','fields','DocType',4,'test_date','Test Date',NULL,'Date',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00309','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Sandbox','fields','DocType',5,'to_be_dropped','to be dropped',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00310','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',1,NULL,'Details',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00311','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',2,'disabled','Disabled','disabled','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00312','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',3,'module','Module','module','Link','Link','Module Def',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00313','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',4,'standard','Standard','standard','Select','Select','\nYes\nNo',1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00314','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',5,'criteria_name','Criteria Name','criteria_name','Data','Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00315','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',6,'description','Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'300px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00316','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',7,NULL,'Query Details',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00317','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',8,'doc_type','Doc Type','doc_type','Data','Data',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00318','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',9,'filters','Filters','filters','Text','Text',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00319','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',10,'columns','Columns','columns','Text','Text',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00320','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',11,'parent_doc_type','Parent Doc Type','parent_doc_type','Data','Data',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00321','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',12,'add_cond','Additional Conditions','add_cond','Text','Text',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00322','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',13,'add_col','Additional Columns','add_col','Text','Text',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00323','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',14,'add_tab','Additional Tables','add_tab','Text','Text',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00324','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',15,'dis_filters','Disabled Filters','dis_filters','Text','Text',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00325','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',16,'group_by','Group By','group_by','Data','Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00326','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',17,'graph_series','Graph Series','graph_series','Data','Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00327','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',18,'graph_values','Graph Values','graph_values','Data','Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00328','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',19,'sort_by','Sort By','sort_by','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00329','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',20,'sort_order','Sort Order','sort_order','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00330','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',21,'page_len','Page Len','page_len','Int','Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00331','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',22,NULL,'Client Script',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00332','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',23,'report_script','Report Script','report_script','Code','Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00333','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',24,NULL,'Server Script',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00334','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',25,'server_script','Report Server Script','server_script','Code','Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00335','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',26,NULL,'Overload Query',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00336','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','fields','DocType',27,'custom_query','Custom Query','custom_query','Code','Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00337','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Stylesheet','fields','DocType',1,'stylesheet_name','Stylesheet Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00338','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Stylesheet','fields','DocType',2,'module','Module',NULL,'Link',NULL,'Module Def',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00339','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Stylesheet','fields','DocType',3,'stylesheet','Stylesheet',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00340','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'System Console','fields','DocType',1,'script','Script',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00341','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'System Console','fields','DocType',2,NULL,'Server (Python)',NULL,'Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Client',NULL,0,NULL,NULL,NULL,'White:FFF',NULL,NULL,NULL),('FL00342','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'System Console','fields','DocType',3,NULL,'Client (JS)',NULL,'Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Client',NULL,0,NULL,NULL,NULL,'White:FFF',NULL,NULL,NULL),('FL00343','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'System Console','fields','DocType',4,'response','Error',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00344','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',1,'from_table','From Table','from_table','Select','Select','link:DocType',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,'140px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00345','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',2,'to_table','To Table','to_table','Select','Select','link:DocType',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,'140px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00346','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',3,'from_field','From Field','from_field','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'140px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00347','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',4,'to_field','To Field','to_field','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'140px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00348','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',5,'match_id','Match Id','match_id','Int','Int',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'60px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00349','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',6,'validation_logic','Validation Logic','validation_logic','Small Text','Small Text',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,'150px',NULL,NULL,NULL,NULL,NULL,NULL),('FL00350','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',7,'reference_doctype_key','Reference DocType Key','reference_doctype_key','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00351','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Table Mapper Detail','fields','DocType',8,'reference_key','Reference Docname Key','reference_key','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00352','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Tag','fields','DocType',1,'tag_name','Tag Name','tag_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00353','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Tag','fields','DocType',2,NULL,'Tag Details',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00354','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Tag','fields','DocType',3,'tag_details','Tag Details1','tag_details','Table','Table','Tag Detail',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('FL00355','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'UserRole','fields','DocType',1,'role','Role','role','Link','Link','Role',0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,0,'200px',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocField` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocFormat`
--

DROP TABLE IF EXISTS `tabDocFormat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocFormat` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `format` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocFormat`
--

LOCK TABLES `tabDocFormat` WRITE;
/*!40000 ALTER TABLE `tabDocFormat` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDocFormat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocPerm`
--

DROP TABLE IF EXISTS `tabDocPerm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocPerm` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `permlevel` int(11) DEFAULT '0',
  `role` varchar(180) DEFAULT NULL,
  `match` varchar(180) DEFAULT NULL,
  `read` int(1) DEFAULT NULL,
  `write` int(1) DEFAULT NULL,
  `create` int(1) DEFAULT NULL,
  `submit` int(1) DEFAULT NULL,
  `cancel` int(1) DEFAULT NULL,
  `amend` int(1) DEFAULT NULL,
  `execute` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocPerm`
--

LOCK TABLES `tabDocPerm` WRITE;
/*!40000 ALTER TABLE `tabDocPerm` DISABLE KEYS */;
INSERT INTO `tabDocPerm` VALUES ('000000001','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','permissions','DocType',NULL,0,'System Manager',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('000000002','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,NULL,0),('000000003','2011-07-22 19:08:54','2011-07-22 19:08:54','Administrator','Administrator',0,'DocType','permissions','DocType',2,1,'Administrator',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('000000049','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,'DocField','permissions','DocType',1,0,'Administrator',NULL,0,0,0,0,0,NULL,0),('PERM00001','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Comment Widget Record','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00002','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,'Control Panel','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,NULL,0),('PERM00003','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,1,NULL,NULL),('PERM00004','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','permissions','DocType',2,1,'Administrator',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00005','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','permissions','DocType',3,2,'Administrator',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00006','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','permissions','DocType',4,0,'System Manager',NULL,1,1,1,NULL,1,NULL,NULL),('PERM00007','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Field','permissions','DocType',5,1,'System Manager',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00008','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Script','permissions','DocType',NULL,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00009','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'Custom Script','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00010','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,'DocType Label','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00011','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00012','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'DocType Mapper','permissions','DocType',2,1,'Administrator',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00013','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'Event','permissions','DocType',1,0,'All','owner',1,1,1,NULL,NULL,NULL,NULL),('PERM00014','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','permissions','DocType',1,0,'All','owner',1,1,1,NULL,NULL,0,NULL),('PERM00015','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File','permissions','DocType',2,1,'All',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00016','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,'File Group','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00017','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Letter Head','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00018','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Module Def','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00019','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,'Page','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,NULL,0),('PERM00020','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Print Format','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,NULL,0),('PERM00021','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,NULL,0),('PERM00022','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','permissions','DocType',2,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00023','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','permissions','DocType',3,1,'Administrator',NULL,1,1,NULL,NULL,NULL,NULL,NULL),('PERM00024','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,'Profile','permissions','DocType',4,0,'All','owner',1,1,NULL,NULL,NULL,NULL,NULL),('PERM00025','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,1,NULL,NULL),('PERM00026','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Property Setter','permissions','DocType',2,0,'System Manager',NULL,1,1,1,NULL,1,NULL,NULL),('PERM00027','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Role','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,NULL,0),('PERM00028','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Sandbox','permissions','DocType',1,0,'Administrator',NULL,1,1,1,1,1,1,1),('PERM00029','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','permissions','DocType',1,0,'All',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00030','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','permissions','DocType',2,1,'All',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00031','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','permissions','DocType',3,0,'Administrator',NULL,1,1,NULL,NULL,NULL,NULL,NULL),('PERM00032','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,'Search Criteria','permissions','DocType',4,1,'Administrator',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00033','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'System Console','permissions','DocType',1,0,'Administrator',NULL,1,1,1,NULL,NULL,NULL,NULL),('PERM00034','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'System Console','permissions','DocType',2,1,'Administrator',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('PERM00035','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Tag','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocPerm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocTrigger`
--

DROP TABLE IF EXISTS `tabDocTrigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocTrigger` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `doc_name` varchar(180) DEFAULT NULL,
  `doc_type` varchar(180) DEFAULT NULL,
  `event_name` varchar(180) DEFAULT NULL,
  `method` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocTrigger`
--

LOCK TABLES `tabDocTrigger` WRITE;
/*!40000 ALTER TABLE `tabDocTrigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDocTrigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType`
--

DROP TABLE IF EXISTS `tabDocType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType` (
  `name` varchar(180) NOT NULL DEFAULT '',
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(180) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `search_fields` varchar(180) DEFAULT NULL,
  `issingle` int(1) DEFAULT NULL,
  `istable` int(1) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `module` varchar(180) DEFAULT NULL,
  `autoname` varchar(180) DEFAULT NULL,
  `name_case` varchar(180) DEFAULT NULL,
  `description` text,
  `colour` varchar(180) DEFAULT NULL,
  `read_only` int(1) DEFAULT NULL,
  `in_create` int(1) DEFAULT NULL,
  `show_in_menu` int(1) DEFAULT NULL,
  `menu_index` int(11) DEFAULT NULL,
  `parent_node` varchar(180) DEFAULT NULL,
  `smallicon` varchar(180) DEFAULT NULL,
  `allow_print` int(1) DEFAULT NULL,
  `allow_email` int(1) DEFAULT NULL,
  `allow_copy` int(1) DEFAULT NULL,
  `allow_rename` int(1) DEFAULT NULL,
  `hide_toolbar` int(1) DEFAULT NULL,
  `hide_heading` int(1) DEFAULT NULL,
  `allow_attach` int(1) DEFAULT NULL,
  `use_template` int(1) DEFAULT NULL,
  `max_attachments` int(11) DEFAULT NULL,
  `section_style` varchar(180) DEFAULT NULL,
  `client_script` text,
  `client_script_core` text,
  `server_code` text,
  `server_code_core` text,
  `server_code_compiled` text,
  `client_string` text,
  `server_code_error` varchar(180) DEFAULT NULL,
  `print_outline` varchar(180) DEFAULT NULL,
  `dt_template` text,
  `is_transaction_doc` int(1) DEFAULT NULL,
  `change_log` text,
  `read_only_onload` int(1) DEFAULT NULL,
  `tag_fields` varchar(180) DEFAULT NULL,
  `in_dialog` int(1) DEFAULT NULL,
  `subject` varchar(180) DEFAULT NULL,
  `document_type` varchar(180) DEFAULT NULL,
  `allow_trash` int(1) DEFAULT NULL,
  `_last_update` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType`
--

LOCK TABLES `tabDocType` WRITE;
/*!40000 ALTER TABLE `tabDocType` DISABLE KEYS */;
INSERT INTO `tabDocType` VALUES ('Comment Widget Record','2011-07-22 19:08:56','2011-07-22 19:08:56','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,NULL,8,'Core','CWR/.#####',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Control Panel','2011-07-22 19:08:56','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,1,0,21,'Core',NULL,NULL,NULL,'White:FFF',0,1,1,5,NULL,'controller.png',0,0,0,NULL,0,0,NULL,NULL,NULL,'Tray',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Custom Field','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'dt,label,fieldtype,options',NULL,NULL,158,'Core','CustomField.####',NULL,'Adds a custom field to a DocType','White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,'    \n  # Add Field\n  # ----------\n  def add_field(self):\n    field_exists = sql(\"select name from tabDocField where parent = %s and (label = %s or fieldname = %s)\" , (self.doc.dt, self.doc.label, self.doc.fieldname))\n    field_exists = field_exists and field_exists[0][0] or \'\'\n    self.ignore_fields = [\'dt\',\'trash_reason\',\'insert_after\',\'index\',\'customfield1\',\'length\']\n    if field_exists:\n      df = Document(\'DocField\',field_exists)\n      self.update_field(df, n = 0)\n    else:\n      df = Document(\'DocField\')\n      self.update_field(df, n = 1)\n\n\n\n  # Update Field\n  # -------------\n  def update_field(self, df, n):\n    import webnotes.model\n    sql(\"update tabDocField set idx = idx + 1 where parent = %s and idx > %s\", (self.doc.dt, self.idx))\n    for k in self.doc.fields:\n      if k not in webnotes.model.default_fields and k not in self.ignore_fields:\n        df.fields[k] = self.doc.fields[k]\n    df.parent = self.doc.dt\n    df.parenttype = \'DocType\'\n    df.parentfield = \'fields\'\n    df.idx = self.idx+1\n    df.save(n)\n    dt_obj = get_obj(\'DocType\',self.doc.dt,with_children=1)\n    dt_obj.validate()\n    dt_obj.on_update()\n    dt_obj.doc.save()',NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Custom Script','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'Core','CustomScript.####',NULL,'Adds a custom script (client or server) to a DocType','White:FFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Default Home Page','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,2,'Core',NULL,NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DefaultValue','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,1,NULL,'Core','DEF.######',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocField','2011-07-22 19:08:55','2011-07-22 19:08:55','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,1,4,'Core','FL.#####',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocFormat','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,1,NULL,'Core','DF.######',NULL,NULL,'White:FFF',0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocPerm','2011-07-22 19:08:55','2011-07-22 19:08:56','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,1,NULL,'Core','PERM.#####',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocTrigger','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'Core','_TRIGGER.######',NULL,NULL,'White:FFF',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocType','2011-07-22 19:08:54','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,0,'autoname',0,0,8,'Core','Prompt',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ','Yes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocType Label','2011-07-22 19:08:57','2011-07-22 19:08:57','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'Core','field:dt',NULL,NULL,'White:FFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocType Mapper','2011-07-22 19:08:57','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,NULL,9,'Core',NULL,NULL,NULL,'White:FFF',NULL,NULL,0,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Event','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'Core','EV.#####',NULL,NULL,'White:FFF',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tabbed','cur_frm.cscript.onload = function(doc, cdt, cdn) {\n  var df = get_field(\'Event\', \'Intro HTML\', doc.name);\n  if(doc.ref_type) {\n    ref = repl(cur_frm.cstring.ref_html, {\'dt\': doc.ref_type, \'dn\':doc.ref_name});\n  } else var ref = \'\';\n     \n  df.options = repl(cur_frm.cstring.intro_html, {\'ref\': ref});\n  refresh_fields(\'Intro HTML\');\n}',NULL,NULL,NULL,NULL,'---intro_html---\n\n<div style=\"padding: 8px; background-color: #EEF; border: 1px solid #CCF; margin-bottom: 8px;\">\n  %(ref)s\n  <a href=\"javascript:loadpage(\'_calendar\')\">Go To Calendar</a>\n</div>\n\n---ref_html---\n\nReference : <a href=\"javascript:loaddoc(\'%(dt)s\', \'%(dn)s\')\">%(dn)s</a><br><br>',' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1311340897'),('Event Role','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'Core','__EVR.#####',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Event User','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'Core','EVP.#####',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Field Mapper Detail','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,10,'Core','FMD/.#####',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tray',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('File','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'type, file_group',NULL,NULL,7,'Core','field:file_name',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'Simple',NULL,NULL,'class DocType:\n  def __init__(self, d, dl):\n    self.doc, self.doclist = d,dl\n\n  def validate(self):\n    # check for extension\n    if not \'.\' in self.doc.file_name:\n      msgprint(\"Extension required in file name\")\n      raise Exception\n\n    # set mime type\n    if not self.doc.mime_type:\n      import mimetypes\n      self.doc.mime_type = mimetypes.guess_type(self.doc.file_name)[0] or \'application/unknown\'',NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('File Data','2011-07-22 19:08:58','2011-07-22 19:08:58','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Core','FileData/.#####',NULL,NULL,'White:FFF',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('File Group','2011-07-22 19:08:58','2011-07-22 19:08:59','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'Core','field:group_name',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Master',NULL,NULL),('Letter Head','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'Core','field:letter_head_name',NULL,NULL,'White:FFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,3,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Module Def','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'doctype_list',NULL,NULL,2,'Core','field:module_name',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Module Def Item','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,15,'Core','MDI.#####',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Module Def Role','2011-07-22 19:08:59','2011-07-22 19:08:59','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'Core','MDR.#####',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Page','2011-07-22 19:08:59','2011-07-22 19:09:00','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,0,8,'Core','field:page_name',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Tabbed',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1311340897'),('Page Role','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,1,NULL,'Core','PR.######',NULL,NULL,'White:FFF',0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Page Template','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,'Core','field:template_name',NULL,'Page Template is used in the CMS. In Page, if you select a template, the page appears within the template.\n\n<b>Note:</b> The template must have a \"%(content)s\" for string replacement and all % must be %%!\n\nIn developer_mode, the template is saved to the file system. ','White:FFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Print Format','2011-07-22 19:09:00','2011-07-22 19:09:00','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,0,3,'Core','Prompt',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Profile','2011-07-22 19:09:00','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,0,25,'Core',NULL,NULL,NULL,'White:FFF',0,1,0,NULL,NULL,NULL,0,0,0,NULL,0,0,1,NULL,1,'Tray','cur_frm.cscript[\'Change Password\']= function(doc, cdt, cdn) {\n   var error = false;\n   if ((!doc.new_password)||(!doc.retype_new_password)){\n      alert(\"Both fields are required!\");\n      error = true;\n   }\n   if (doc.new_password.length<4) {\n      alert(\"Password must be atleast 4 characters long\");\n      error = true;\n   }\n   if(doc.new_password!=doc.retype_new_password) {\n      alert(\"Passwords must match\");\n      error = true;\n   }\n   if(!/[A-Z]/.test(doc.new_password) || !/[0-9]/.test(doc.new_password) || !/[\\W_]/.test(doc.new_password)) {\n      msgprint(\'New password must contain atleast 1 capital letter, 1 numeric and 1 special character.\');\n      error = true;\n      doc.new_password = \'\';\n      refresh_field(\'new_password\');\n   }\n   if(!error) {\n      cur_frm.runscript(\'update_password\', \'\', function(r,t) {\n	doc.new_password = \'\';\n	doc.retype_new_password = \'\';\n        refresh_many([\'new_password\',\'retype_new_password\']);\n      });\n   }\n}\n\ncur_frm.cscript.validate = function(doc, cdt, cdn) {\n  doc.new_password = \'\';\n  doc.retype_new_password = \'\';\n}',NULL,NULL,NULL,NULL,NULL,' ','Yes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Property Setter','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'doc_name,property',NULL,NULL,36,'Core','eval:doc.select_doctype + \'-\' + (doc.select_item or doc.doc_name) + \'-\' + doc.property',NULL,'Property Setter overrides a standard DocType or Field property','White:FFF',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'property',NULL,'<b>%(property)s</b> property of %(doc_type)s %(doc_name)s',NULL,1,NULL),('Role','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,0,1,'Core','field:role_name',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Sandbox','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'Core','_SD.####',NULL,NULL,'White:FFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Search Criteria','2011-07-22 19:09:01','2011-07-22 19:09:01','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'criteria_name',NULL,NULL,4,'Core',NULL,NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tabbed',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1311340897'),('Stylesheet','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,'Core','field:stylesheet_name',NULL,NULL,'White:FFF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('System Console','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,1,NULL,6,'Core',NULL,NULL,NULL,'White:FFF',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System',NULL,NULL),('Table Mapper Detail','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,5,'Core','TMD/.#######',NULL,NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tray',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Tag','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,'Core','field:tag_name','Title Case',NULL,'White:FFF',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('UserRole','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,1,NULL,'Core','UR.#####',NULL,NULL,'White:FFF',0,NULL,0,NULL,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,NULL,'Simple',NULL,NULL,NULL,NULL,NULL,NULL,' ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType Label`
--

DROP TABLE IF EXISTS `tabDocType Label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType Label` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `dt` varchar(180) DEFAULT NULL,
  `dt_label` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType Label`
--

LOCK TABLES `tabDocType Label` WRITE;
/*!40000 ALTER TABLE `tabDocType Label` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDocType Label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType Mapper`
--

DROP TABLE IF EXISTS `tabDocType Mapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType Mapper` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `to_doctype` varchar(180) DEFAULT NULL,
  `ref_doc_submitted` int(1) DEFAULT NULL,
  `module` varchar(180) DEFAULT NULL,
  `from_doctype` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType Mapper`
--

LOCK TABLES `tabDocType Mapper` WRITE;
/*!40000 ALTER TABLE `tabDocType Mapper` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDocType Mapper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEvent`
--

DROP TABLE IF EXISTS `tabEvent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEvent` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `description` text,
  `event_name` varchar(180) DEFAULT NULL,
  `notes` text,
  `event_type` varchar(180) DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `ref_type` varchar(180) DEFAULT NULL,
  `ref_name` varchar(180) DEFAULT NULL,
  `event_hour` time DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEvent`
--

LOCK TABLES `tabEvent` WRITE;
/*!40000 ALTER TABLE `tabEvent` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEvent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEvent Role`
--

DROP TABLE IF EXISTS `tabEvent Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEvent Role` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEvent Role`
--

LOCK TABLES `tabEvent Role` WRITE;
/*!40000 ALTER TABLE `tabEvent Role` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEvent Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEvent User`
--

DROP TABLE IF EXISTS `tabEvent User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEvent User` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `person` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEvent User`
--

LOCK TABLES `tabEvent User` WRITE;
/*!40000 ALTER TABLE `tabEvent User` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEvent User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabField Mapper Detail`
--

DROP TABLE IF EXISTS `tabField Mapper Detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabField Mapper Detail` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `map` varchar(180) DEFAULT NULL,
  `to_field` varchar(180) DEFAULT NULL,
  `match_id` int(11) DEFAULT '0',
  `checking_operator` varchar(180) DEFAULT NULL,
  `from_field` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabField Mapper Detail`
--

LOCK TABLES `tabField Mapper Detail` WRITE;
/*!40000 ALTER TABLE `tabField Mapper Detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabField Mapper Detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabFile`
--

DROP TABLE IF EXISTS `tabFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabFile` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `can_edit` text,
  `description` text,
  `file_name` varchar(180) DEFAULT NULL,
  `shared_with` text,
  `can_view` text,
  `type` varchar(180) DEFAULT NULL,
  `file_list` text,
  `file_group` varchar(180) DEFAULT NULL,
  `mime_type` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabFile`
--

LOCK TABLES `tabFile` WRITE;
/*!40000 ALTER TABLE `tabFile` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabFile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabFile Data`
--

DROP TABLE IF EXISTS `tabFile Data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabFile Data` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `file_name` varchar(180) DEFAULT NULL,
  `module` varchar(180) DEFAULT NULL,
  `blob_content` longblob,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabFile Data`
--

LOCK TABLES `tabFile Data` WRITE;
/*!40000 ALTER TABLE `tabFile Data` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabFile Data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabFile Group`
--

DROP TABLE IF EXISTS `tabFile Group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabFile Group` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `can_edit` text,
  `description` text,
  `is_parent` int(1) DEFAULT NULL,
  `shared_with` text,
  `can_view` text,
  `group_name` varchar(180) DEFAULT NULL,
  `parent_group` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabFile Group`
--

LOCK TABLES `tabFile Group` WRITE;
/*!40000 ALTER TABLE `tabFile Group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabFile Group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabLetter Head`
--

DROP TABLE IF EXISTS `tabLetter Head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabLetter Head` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `is_default` int(1) DEFAULT NULL,
  `url` varchar(180) DEFAULT NULL,
  `letter_head_name` varchar(180) DEFAULT NULL,
  `disabled` int(1) DEFAULT NULL,
  `file_list` text,
  `content` text,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabLetter Head`
--

LOCK TABLES `tabLetter Head` WRITE;
/*!40000 ALTER TABLE `tabLetter Head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabLetter Head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabModule Def`
--

DROP TABLE IF EXISTS `tabModule Def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabModule Def` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `module_icon` varchar(180) DEFAULT NULL,
  `trash_reason` text,
  `module_page` varchar(180) DEFAULT NULL,
  `disabled` varchar(180) DEFAULT NULL,
  `module_label` varchar(180) DEFAULT NULL,
  `widget_code` text,
  `file_list` text,
  `module_name` varchar(180) DEFAULT NULL,
  `is_hidden` varchar(180) DEFAULT NULL,
  `module_desc` varchar(180) DEFAULT NULL,
  `module_seq` int(11) DEFAULT NULL,
  `doctype_list` text,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabModule Def`
--

LOCK TABLES `tabModule Def` WRITE;
/*!40000 ALTER TABLE `tabModule Def` DISABLE KEYS */;
INSERT INTO `tabModule Def` VALUES ('Core','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'No','Core',NULL,NULL,'Core','Yes',NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabModule Def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabModule Def Item`
--

DROP TABLE IF EXISTS `tabModule Def Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabModule Def Item` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `doc_type` varchar(180) DEFAULT NULL,
  `display_name` varchar(180) DEFAULT NULL,
  `description` text,
  `fields` text,
  `doc_name` varchar(180) DEFAULT NULL,
  `hide` int(1) DEFAULT NULL,
  `click_function` varchar(180) DEFAULT NULL,
  `icon` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabModule Def Item`
--

LOCK TABLES `tabModule Def Item` WRITE;
/*!40000 ALTER TABLE `tabModule Def Item` DISABLE KEYS */;
INSERT INTO `tabModule Def Item` VALUES ('MDI00001','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Core','items','Module Def',NULL,'Separator',NULL,NULL,NULL,'Pages',NULL,NULL,NULL),('MDI00002','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Core','items','Module Def',NULL,'Pages','Manage Users',NULL,NULL,'Manage Users',NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabModule Def Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabModule Def Role`
--

DROP TABLE IF EXISTS `tabModule Def Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabModule Def Role` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabModule Def Role`
--

LOCK TABLES `tabModule Def Role` WRITE;
/*!40000 ALTER TABLE `tabModule Def Role` DISABLE KEYS */;
INSERT INTO `tabModule Def Role` VALUES ('MDR00001','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Core','roles','Module Def',1,'Administrator');
/*!40000 ALTER TABLE `tabModule Def Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPage`
--

DROP TABLE IF EXISTS `tabPage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPage` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `style` text,
  `script` text,
  `static_content` text,
  `module` varchar(180) DEFAULT NULL,
  `standard` varchar(180) DEFAULT NULL,
  `content` text,
  `page_name` varchar(180) DEFAULT NULL,
  `menu_index` int(11) DEFAULT NULL,
  `show_in_menu` int(1) DEFAULT NULL,
  `parent_node` varchar(180) DEFAULT NULL,
  `icon` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPage`
--

LOCK TABLES `tabPage` WRITE;
/*!40000 ALTER TABLE `tabPage` DISABLE KEYS */;
INSERT INTO `tabPage` VALUES ('Login Page','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Core','Yes',NULL,'Login Page',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabPage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPage Role`
--

DROP TABLE IF EXISTS `tabPage Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPage Role` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPage Role`
--

LOCK TABLES `tabPage Role` WRITE;
/*!40000 ALTER TABLE `tabPage Role` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPage Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPage Template`
--

DROP TABLE IF EXISTS `tabPage Template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPage Template` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `template_name` varchar(180) DEFAULT NULL,
  `template` text,
  `module` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPage Template`
--

LOCK TABLES `tabPage Template` WRITE;
/*!40000 ALTER TABLE `tabPage Template` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPage Template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPrint Format`
--

DROP TABLE IF EXISTS `tabPrint Format`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPrint Format` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `html` text,
  `module` varchar(180) DEFAULT NULL,
  `standard` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPrint Format`
--

LOCK TABLES `tabPrint Format` WRITE;
/*!40000 ALTER TABLE `tabPrint Format` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPrint Format` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabProfile`
--

DROP TABLE IF EXISTS `tabProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabProfile` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `last_name` varchar(180) DEFAULT NULL,
  `pin` varchar(180) DEFAULT NULL,
  `activities` text,
  `send_email_invite` int(1) DEFAULT '1',
  `last_ip` varchar(180) DEFAULT NULL,
  `user_type` varchar(180) DEFAULT NULL,
  `file_list` text,
  `social_badge` varchar(180) DEFAULT NULL,
  `cell_no` varchar(180) DEFAULT NULL,
  `recent_documents` text,
  `occupation` varchar(180) DEFAULT NULL,
  `city` varchar(180) DEFAULT NULL,
  `first_name` varchar(180) DEFAULT NULL,
  `middle_name` varchar(180) DEFAULT NULL,
  `district` varchar(180) DEFAULT NULL,
  `new_password` varchar(180) DEFAULT NULL,
  `retype_new_password` varchar(180) DEFAULT NULL,
  `state` varchar(180) DEFAULT NULL,
  `last_login` varchar(180) DEFAULT NULL,
  `home_phone` varchar(180) DEFAULT NULL,
  `line_1` varchar(180) DEFAULT NULL,
  `line_2` varchar(180) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `interests` text,
  `bio` text,
  `password_last_updated` date DEFAULT NULL,
  `fiscal_year` varchar(180) DEFAULT NULL,
  `messanger_status` varchar(180) DEFAULT NULL,
  `password` varchar(180) DEFAULT NULL,
  `extension` varchar(180) DEFAULT NULL,
  `gender` varchar(180) DEFAULT NULL,
  `enabled` int(1) DEFAULT '1',
  `office_phone` varchar(180) DEFAULT NULL,
  `social_points` int(11) DEFAULT '0',
  `avatar` varchar(180) DEFAULT NULL,
  `country` varchar(180) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabProfile`
--

LOCK TABLES `tabProfile` WRITE;
/*!40000 ALTER TABLE `tabProfile` DISABLE KEYS */;
INSERT INTO `tabProfile` VALUES ('Administrator','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'127.0.0.1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Administrator',NULL,NULL,NULL,NULL,NULL,'2011-07-22 21:12:39',NULL,NULL,NULL,'admin@localhost',NULL,NULL,NULL,NULL,NULL,'*4ACFE3202A5FF5CF467898FC58AAB1D615029441',NULL,NULL,1,NULL,0,NULL,NULL,NULL),('Guest','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'127.0.0.1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guest',NULL,NULL,NULL,NULL,NULL,'2011-07-22 22:43:14',NULL,NULL,NULL,'guest@localhost',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabProfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabProperty Setter`
--

DROP TABLE IF EXISTS `tabProperty Setter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabProperty Setter` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `default_value` varchar(180) DEFAULT NULL,
  `doc_type` varchar(180) DEFAULT NULL,
  `property_type` varchar(180) DEFAULT NULL,
  `select_property` varchar(180) DEFAULT NULL,
  `value` text,
  `doc_name` varchar(180) DEFAULT NULL,
  `select_doctype` varchar(180) DEFAULT NULL,
  `doctype_or_field` varchar(180) DEFAULT NULL,
  `select_item` varchar(180) DEFAULT NULL,
  `property` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabProperty Setter`
--

LOCK TABLES `tabProperty Setter` WRITE;
/*!40000 ALTER TABLE `tabProperty Setter` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabProperty Setter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabRole`
--

DROP TABLE IF EXISTS `tabRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabRole` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role_name` varchar(180) DEFAULT NULL,
  `module` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabRole`
--

LOCK TABLES `tabRole` WRITE;
/*!40000 ALTER TABLE `tabRole` DISABLE KEYS */;
INSERT INTO `tabRole` VALUES ('Administrator','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,0,'Administrator','Core'),('All','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'All','Core'),('Guest','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Guest','Core');
/*!40000 ALTER TABLE `tabRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSandbox`
--

DROP TABLE IF EXISTS `tabSandbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSandbox` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `test_data` varchar(180) DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `test_link` varchar(180) DEFAULT NULL,
  `test_text` text,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSandbox`
--

LOCK TABLES `tabSandbox` WRITE;
/*!40000 ALTER TABLE `tabSandbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabSandbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSearch Criteria`
--

DROP TABLE IF EXISTS `tabSearch Criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSearch Criteria` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `custom_query` text,
  `filters` text,
  `add_col` text,
  `parent_doc_type` varchar(180) DEFAULT NULL,
  `module` varchar(180) DEFAULT NULL,
  `disabled` int(1) DEFAULT NULL,
  `sort_order` varchar(180) DEFAULT NULL,
  `add_tab` text,
  `report_script` text,
  `server_script` text,
  `group_by` varchar(180) DEFAULT NULL,
  `graph_series` varchar(180) DEFAULT NULL,
  `criteria_name` varchar(180) DEFAULT NULL,
  `columns` text,
  `graph_values` varchar(180) DEFAULT NULL,
  `description` text,
  `standard` varchar(180) DEFAULT NULL,
  `dis_filters` text,
  `doc_type` varchar(180) DEFAULT NULL,
  `add_cond` text,
  `sort_by` varchar(180) DEFAULT NULL,
  `page_len` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSearch Criteria`
--

LOCK TABLES `tabSearch Criteria` WRITE;
/*!40000 ALTER TABLE `tabSearch Criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabSearch Criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSeries`
--

DROP TABLE IF EXISTS `tabSeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSeries` (
  `name` varchar(40) DEFAULT NULL,
  `current` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSeries`
--

LOCK TABLES `tabSeries` WRITE;
/*!40000 ALTER TABLE `tabSeries` DISABLE KEYS */;
INSERT INTO `tabSeries` VALUES ('',49),('FL',355),('PERM',35),('MDI',2),('MDR',1),('DEF',2),('UR',2);
/*!40000 ALTER TABLE `tabSeries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSessions`
--

DROP TABLE IF EXISTS `tabSessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSessions` (
  `user` varchar(40) DEFAULT NULL,
  `sid` varchar(120) DEFAULT NULL,
  `sessiondata` longtext,
  `ipaddress` varchar(16) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSessions`
--

LOCK TABLES `tabSessions` WRITE;
/*!40000 ALTER TABLE `tabSessions` DISABLE KEYS */;
INSERT INTO `tabSessions` VALUES ('Guest','97e4a729c2829f36b5385080bac79c117aff8eaa9cdb1c9653d713b0','{\'tenant_id\': 0, \'session_ip\': \'127.0.0.1\'}',NULL,'2011-07-22 19:09:11','Active'),('Administrator','776db98f5d3b3480ae198fa0c699d948f57450eca46509a9f7c08394','{\'tenant_id\': 0, \'session_ip\': \'127.0.0.1\'}',NULL,'2011-07-22 21:11:43','Logged Out'),('Guest','7c27d7aa7bc609ebd94f772f095093cc0a3f88a4d73dc12256981d46','{\'tenant_id\': 0, \'session_ip\': \'127.0.0.1\'}',NULL,'2011-07-22 21:12:29','Active'),('Administrator','d5d46c47ee2afbb4d4e63ed53309d446dbea4645573f428342699d8a','{\'tenant_id\': 0, \'session_ip\': \'127.0.0.1\'}',NULL,'2011-07-22 21:12:43','Logged Out'),('Guest','29eb81b83491aa50e45e461661ab3a7f5de93a1ecfc5fc2d062d1dd6','{\'profile\': {\'first_name\': \'Guest\', \'last_name\': \'\', \'name\': \'Guest\', \'roles\': [\'Guest\', \'Guest\'], \'hide_tips\': 0, \'can_get_report\': [], \'can_read\': [], \'defaults\': {\'owner\': [\'Guest\'], \'hide_sidebars\': [\'1\'], \'hide_webnotes_toolbar\': [\'1\']}, \'can_write\': [], \'can_create\': [], \'email\': \'guest@localhost\', \'recent\': \'\'}, \'tenant_id\': 0, \'session_ip\': \'127.0.0.1\'}',NULL,'2011-07-22 22:43:22','Active');
/*!40000 ALTER TABLE `tabSessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSingles`
--

DROP TABLE IF EXISTS `tabSingles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSingles` (
  `doctype` varchar(40) DEFAULT NULL,
  `field` varchar(40) DEFAULT NULL,
  `value` text,
  KEY `doctype` (`doctype`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSingles`
--

LOCK TABLES `tabSingles` WRITE;
/*!40000 ALTER TABLE `tabSingles` DISABLE KEYS */;
INSERT INTO `tabSingles` VALUES ('DocType','modified','2011-05-16 10:19:14');
/*!40000 ALTER TABLE `tabSingles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabStylesheet`
--

DROP TABLE IF EXISTS `tabStylesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabStylesheet` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `stylesheet` text,
  `stylesheet_name` varchar(180) DEFAULT NULL,
  `module` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabStylesheet`
--

LOCK TABLES `tabStylesheet` WRITE;
/*!40000 ALTER TABLE `tabStylesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabStylesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabTable Mapper Detail`
--

DROP TABLE IF EXISTS `tabTable Mapper Detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabTable Mapper Detail` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `reference_key` varchar(180) DEFAULT NULL,
  `match_id` int(11) DEFAULT NULL,
  `reference_doctype_key` varchar(180) DEFAULT NULL,
  `to_field` varchar(180) DEFAULT NULL,
  `from_field` varchar(180) DEFAULT NULL,
  `from_table` varchar(180) DEFAULT NULL,
  `to_table` varchar(180) DEFAULT NULL,
  `validation_logic` text,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabTable Mapper Detail`
--

LOCK TABLES `tabTable Mapper Detail` WRITE;
/*!40000 ALTER TABLE `tabTable Mapper Detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabTable Mapper Detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabTag`
--

DROP TABLE IF EXISTS `tabTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabTag` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `tag_name` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabTag`
--

LOCK TABLES `tabTag` WRITE;
/*!40000 ALTER TABLE `tabTag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabTag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabUserRole`
--

DROP TABLE IF EXISTS `tabUserRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabUserRole` (
  `name` varchar(120) NOT NULL,
  `creation` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` varchar(40) DEFAULT NULL,
  `owner` varchar(40) DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(120) DEFAULT NULL,
  `parentfield` varchar(120) DEFAULT NULL,
  `parenttype` varchar(120) DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabUserRole`
--

LOCK TABLES `tabUserRole` WRITE;
/*!40000 ALTER TABLE `tabUserRole` DISABLE KEYS */;
INSERT INTO `tabUserRole` VALUES ('UR00001','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Administrator','userroles','Profile',NULL,'Administrator'),('UR00002','2011-07-22 19:09:02','2011-07-22 19:09:02','Administrator','Administrator',0,'Guest','userroles','Profile',NULL,'Guest');
/*!40000 ALTER TABLE `tabUserRole` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-08-05  6:57:53
